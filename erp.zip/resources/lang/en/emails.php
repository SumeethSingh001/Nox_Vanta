<?php
return [
    'new_invoice'           => 'New Invoice From Invoices System',
    'dear_user'             => 'Dear :name,',
    'greetings'             => 'Greetings,',
    'find_an_invoice'       => 'Please find the invoice attached.',
    'regards'               => 'Best Regards,',
    'footer'                => 'all copyright reserved',
];
