<div>
    <div class="card">
        <div class="card-header modal-header bg-primary justify-content-start">
            <h4 class="modal-title white">
                <?php echo e(trans('applang.show_sales_invoice') .' # ('. $salesInvoice->inv_number .')'); ?>

            </h4>
            <?php if($salesInvoice->payment_status == 1): ?>
                <span class="badge ml-1 mr-1" style="background-color: red ; color: #FFFFFF"><?php echo e(trans('applang.unpaid')); ?></span>
            <?php elseif($salesInvoice->payment_status == 2): ?>
                <span class="badge ml-1 mr-1" style="background-color: #ff7f00; color: #FFFFFF"> <?php echo e(trans('applang.partially_paid')); ?></span>
            <?php elseif($salesInvoice->payment_status == 3): ?>
                <span class="badge badge-success-custom ml-1 mr-1"> <?php echo e(trans('applang.paid')); ?></span>
            <?php endif; ?>

            <?php if($salesInvoice->receiving_status == 1): ?>
                <span class="badge " style="background-color: yellow; color: black"><?php echo e(trans('applang.under_receive')); ?></span>
            <?php else: ?>
                <span class="badge badge-success"> <?php echo e(trans('applang.received')); ?></span>
            <?php endif; ?>
        </div>
        <div class="card-body mt-1" style="padding-bottom: 13px">

            <div class="custom-card mt-1 mb-1">
                <div class="card-header border-bottom justify-content-start" style="background-color: #f9f9f9">
                    <a href="<?php echo e(route('sales-invoices.edit', $salesInvoice->id)); ?>" class="btn btn-sm btn-light-secondary btn-card-header"><i class="bx bx-edit"></i> <?php echo e(trans('applang.edit')); ?></a>

                    <a href="<?php echo e(route('sendToEmailSalesInvoice', $salesInvoice->id)); ?>"
                       class="btn btn-sm btn-light-secondary btn-card-header">
                        <i class="bx bx-envelope"></i>
                        <?php echo e(trans('applang.send_to_client')); ?>

                    </a>
                    <a href="<?php echo e(route('SalesInvoiceAddPaymentTransaction', $salesInvoice->id)); ?>"
                       class="btn btn-sm btn-light-secondary btn-card-header">
                        <i class="bx bx-credit-card"></i>
                        <?php echo e(trans('applang.add_payment_transaction')); ?>

                    </a>
                    <a href="#"
                       class="btn btn-sm btn-light-secondary btn-card-header">
                        <i class="bx bx-credit-card"></i>
                        <?php echo e(trans('applang.create_sales_return')); ?>

                    </a>
                    <a href="#"
                       class="btn btn-sm btn-light-secondary btn-card-header">
                        <i class="bx bxs-book-add"></i>
                        <?php echo e(trans('applang.add_note_attachment')); ?>

                    </a>
                    <a href="#"
                       class="btn btn-sm btn-light-secondary btn-card-header" id="printInv" onclick="printInv()">
                        <i class="bx bxs-printer"></i>
                        <?php echo e(trans('applang.print')); ?>

                    </a>
                    <a href="<?php echo e(route('SalesInvoicePDF', $salesInvoice->id)); ?>" target="_blank"
                       class="btn btn-sm btn-light-secondary btn-card-header">
                        <i class="bx bxs-file-pdf"></i>
                        PDF
                    </a>

                    <div class="dropdown">
                        <button class="btn btn-sm btn-light-secondary dropdown-toggle btn-card-header" type="button" data-toggle="dropdown" aria-expanded="false">
                            <i class="bx bxs-coupon"></i>
                            <?php echo e(trans('applang.vouchers')); ?>

                        </button>
                        <div class="dropdown-menu <?php echo e(app()->getLocale() == 'ar' ? 'dropdown-menu-right': ''); ?>">
                            <a href="<?php echo e(route('salesInvoicePackageStickerPDF', $salesInvoice->id)); ?>" target="_blank" class="dropdown-item">
                                <?php echo e(trans('applang.package_sticker')); ?>

                            </a>
                            <a href="<?php echo e(route('salesInvoiceReceiptListPDF', $salesInvoice->id)); ?>" target="_blank" class="dropdown-item">
                                <?php echo e(trans('applang.receipt_list')); ?>

                            </a>
                            <a href="<?php echo e(route('salesInvoiceDeliveryStickerPDF', $salesInvoice->id)); ?>" target="_blank" class="dropdown-item">
                                <?php echo e(trans('applang.delivery_sticker')); ?>

                            </a>
                        </div>
                    </div>

                    <a href="#"
                       wire:click.prevent="confirmDeleteInvoice('<?php echo e($salesInvoice->id); ?>','<?php echo e($salesInvoice->inv_number); ?>')"
                       class="btn btn-sm btn-light-secondary btn-card-header-last">
                        <i class="bx bxs-trash"></i>
                        <?php echo e(trans('applang.delete')); ?>

                    </a>
                </div>

                <div class="card-body mt-1">
                    <ul class="nav nav-pills card-header-pills ml-0" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">
                                <?php echo e(trans('applang.the_sales_invoice')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-payments-tab" data-toggle="pill" href="#pills-payments" role="tab" aria-controls="pills-payments" aria-selected="true">
                                <?php echo e(trans('applang.payments')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-warehouse_permissions-tab" data-toggle="pill" href="#pills-warehouse_permissions" role="tab" aria-controls="pills-warehouse_permissions" aria-selected="true">
                                <?php echo e(trans('applang.requisitions')); ?>

                            </a>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade active show" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                            <iframe frameborder="0" src="<?php echo e(route('SalesInvoicePreview', $salesInvoice->id)); ?>" id="InvoicePreview" name="InvoicePreview" width="100%" height="1000"></iframe>
                        </div>

                        <div class="tab-pane fade" id="pills-payments" role="tabpanel" aria-labelledby="pills-payments-tab">
                            <?php echo $__env->make('erp.sales.sales_invoices.sales_invoice_payments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <div class="tab-pane fade" id="pills-warehouse_permissions" role="tabpanel" aria-labelledby="pills-warehouse_permissions-tab">
                            warehouse_permissions
                        </div>
                    </div>
                </div>
            </div>

            <?php if(count($salesInvoice->salesInvoiceAttachments) > 0): ?>
                <div class="custom-card">
                    <div class="card-header border-bottom justify-content-start" style="background-color: #f9f9f9">
                        <h4><?php echo e(trans('applang.attachments')); ?></h4>
                    </div>
                    <div class="card-body mt-1">
                        <table class="table table-responsive-sm table-sm table-striped inv-files shadow" style="width: 100%; text-align: center">
                            <thead class="" >
                            <tr>
                                <th >#</th>
                                <th ><?php echo e(trans('applang.file_name')); ?></th>
                                <th ><?php echo e(trans('applang.created_at')); ?></th>
                                <th><?php echo e(trans('applang.actions')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $salesInvoice->salesInvoiceAttachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index+1); ?></td>
                                    <td><?php echo e($file->attachments); ?></td>
                                    <td><?php echo e($file->created_at->format('d-m-Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('SalesFilePreview', [$salesInvoice->created_at->format('m-Y'), $salesInvoice->inv_number, $file->attachments])); ?>" target="_blank">
                                            <i class="bx bx-show-alt"></i>
                                        </a>
                                        <a href="<?php echo e(route('SalesFileDownload', [$salesInvoice->created_at->format('m-Y'), $salesInvoice->inv_number,$file->attachments])); ?>" class="mr-1 ml-1">
                                            <i class="bx bx-download"></i>
                                        </a>
                                        <a href="#" class="danger" wire:click.prevent="confirmDelete('<?php echo e($file->id); ?>','<?php echo e($file->attachments); ?>')">
                                            <i class="bx bx-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <hr class="hr modal-hr">
            <div class="d-flex justify-content-end mt-2rem">
                <a href="<?php echo e(route('sales-invoices.index')); ?>" class="btn btn-light-secondary" data-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block"><?php echo e(trans('applang.back_btn')); ?></span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/erp/sales/sales-invoices/show-sales-invoice.blade.php ENDPATH**/ ?>