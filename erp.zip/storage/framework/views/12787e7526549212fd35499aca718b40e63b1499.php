<div class="content-body">
    <div class="card">
        
        <div class="card-header justify-content-between bg-secondary bg-lighten-4" style="border-bottom: 1px solid #DDD">
            <div class="btn-group justify-content-start align-items-center">
                <a href="#" data-toggle="modal" data-target="#formModalAddSection" class="btn btn-success mb-0">
                    <i class="bx bx-plus d-sm-inline-block"></i>
                    <span class="d-none d-sm-inline-block"><?php echo e(trans('applang.add')); ?></span>
                </a>
                <?php if(count($checked) > 0): ?>
                    <div class="btn-group">
                        <div class="dropdown">
                            <button class="btn btn-danger dropdown-toggle rounded-0" type="button" id="dropdownMenuButton4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                (<span class="d-none d-sm-inline-block"><?php echo e(trans('applang.selected_rows_is')); ?></span> <?php echo e(count($checked)); ?>)
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton4" style="width: 100%">
                                <a href="#" class="dropdown-item" wire:click.prevent="confirmBulkDelete()">
                                    <i class="bx bx-trash"></i>
                                    <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.delete')); ?></span>
                                </a>
                                <a href="#" class="dropdown-item" wire:click.prevent="exportSelected()"
                                   onclick="confirm('<?php echo e(trans('applang.export_confirm_message')); ?>') || event.stopImmediatePropagation()">
                                    <i class="bx bxs-file-export"></i>
                                    <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.export')); ?></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="#" class="btn btn-info" wire:click.prevent="deselectSelected()">
                        <i class="bx bx-reset d-sm-inline-block"></i>
                        <span class="d-none d-sm-inline-block"><?php echo e(trans('applang.deselect')); ?></span>
                    </a>
                <?php endif; ?>
            </div>

            <div class="btn-group align-items-center">
                <a href="<?php echo e(route('brands.index')); ?>" class="btn btn-sm btn-secondary"><i class="bx bx-tv"></i> <?php echo e(trans('applang.brands')); ?></a>
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-sm btn-secondary"><i class="bx bx-sitemap"></i> <?php echo e(trans('applang.categories')); ?></a>
                <a href="<?php echo e(route('subcategories.index')); ?>" class="btn btn-sm btn-secondary"><i class="bx bx-purchase-tag-alt"></i> <?php echo e(trans('applang.sub_categories')); ?></a>
            </div>
        </div>
        <div class="card-body pt-1">
            
            <div class="form-row">
                <div class="col-md-6">
                    <input wire:model="search" type="text" class="form-control mb-50 custom-input-color" placeholder="<?php echo e(trans('applang.search')); ?>">
                </div>
                <div class="col-md-3">
                    <select wire:model="filterByStatus" class="custom-select mb-50 custom-input-color">
                        <option selected value=""><?php echo e(trans('applang.select_status')); ?></option>
                        <option value="1"><?php echo e(trans('applang.active')); ?></option>
                        <option><?php echo e(trans('applang.suspended')); ?></option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select wire:model="perPage" class="custom-select mb-50 custom-input-color">
                        <option selected><?php echo e(trans('applang.per_page')); ?></option>
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>

            </div>
            <div class="form-row mb-2">
                <div class="col-md-3">
                    <select wire:model="sortAsc" class="custom-select mb-50 custom-input-color">
                        <option selected ><?php echo e(trans('applang.sort_by')); ?></option>
                        <option value="1"><?php echo e(trans('applang.ascending')); ?></option>
                        <option value="0"><?php echo e(trans('applang.descending')); ?></option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select wire:model="sortField" class="custom-select mb-50 custom-input-color">
                        <option selected ><?php echo e(trans('applang.sort_column')); ?></option>
                        <option value="name"><?php echo e(trans('applang.name')); ?></option>
                        <option value="status"><?php echo e(trans('applang.status')); ?></option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button wire:click.prevent="resetSearch" class="btn btn-primary w-100"><?php echo e(trans('applang.reset')); ?></button>
                </div>
            </div>

            
            <div class="row">
                <?php if($selectPage): ?>
                    <div class="col-md-12 mb-2">
                        <div class="d-flex justify-content-start align-items-center">
                            <?php if($selectAll): ?>
                                <div class="d-flex justify-content-start align-items-center">
                                    <p class="mb-0">
                                        <?php echo e(trans('applang.you_have_selected_all')); ?> ( <strong><?php echo e($sections->total()); ?></strong> <?php echo e(trans('applang.items')); ?> ).
                                    </p>
                                </div>
                            <?php else: ?>
                                <div class="d-flex justify-content-start align-items-center">
                                    <p class="mb-0">
                                        <?php echo e(trans('applang.you_have_selected')); ?> ( <strong><?php echo e(count($checked)); ?></strong> <?php echo e(trans('applang.items')); ?> ),
                                        <?php echo e(trans('applang.do_you_want_to_select_all')); ?> ( <strong><?php echo e($sections->total()); ?></strong> <?php echo e(trans('applang.items')); ?> ) ?
                                    </p>
                                    <a href="#" class="btn btn-sm btn-primary ml-1" wire:click="selectAll" title="<?php echo e(trans('applang.select_all')); ?>">
                                        <i class="bx bx-select-multiple d-sm-inline-block"></i>
                                        <span class="d-none d-sm-inline-block"><?php echo e(trans('applang.select_all')); ?></span>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($sections->isNotEmpty()): ?>
                <div class="col-12 col-md-12 table-responsive">
                     <table class="user-view hover" style="width: 100%; border: 1px solid #ddd">
                        <thead class="table-head">
                            <tr>
                                <th>
                                    <fieldset>
                                        <div class="checkbox checkbox-secondary">
                                            <input type="checkbox" id="selectAll" wire:model="selectPage">
                                            <label for="selectAll"></label>
                                        </div>
                                    </fieldset>
                                </th>
                                <th>#</th>
                                <th><?php echo e(trans('applang.name')); ?></th>
                                <th><?php echo e(trans('applang.status')); ?></th>
                                <th><?php echo e(trans('applang.actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e(in_array($section->id ,$checked)? 'table-secondary' : ''); ?>">
                                <td class="no-wrap" style="width: 5%">
                                    <fieldset>
                                        <div class="checkbox checkbox-secondary">
                                            <input type="checkbox" id="section-<?php echo e($section->id); ?>" value="<?php echo e($section->id); ?>" wire:model="checked" class="item_checkbox">
                                            <label for="section-<?php echo e($section->id); ?>"></label>
                                        </div>
                                    </fieldset>
                                </td>
                                <td class="no-wrap" style="width: 5%"><?php echo e($index + 1); ?></td>
                                <td class="no-wrap"><?php echo e($section->name); ?></td>
                                <td class="no-wrap"><span class="badge <?php echo e($section->status == 1 ? 'badge-light-success' : 'badge-light-danger'); ?>"><?php echo e($section->status == 1 ? trans('applang.active') : trans('applang.suspended')); ?></span></td>
                                <td class="no-wrap">
                                    <a href="#" data-toggle="modal" data-target="#formModalEditSection" wire:click.prevent="editSection(<?php echo e($section->id); ?>)"><i class="bx bx-edit-alt"></i></a>
                                    <?php if(count($checked) < 2): ?>
                                        <a href="#" class="text-danger mr-1 ml-1" wire:click.prevent="confirmDelete('<?php echo e($section->id); ?>','<?php echo e($section->name); ?>')"><i class="bx bx-trash"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                        </tbody>

                    </table>
                </div>
                <?php else: ?>
                    <div class="col-12 col-md-12">
                        <p class="text-center"><?php echo e(trans('applang.no_records_yet')); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="d-flex d-flex justify-content-between custom-pagination mt-1">
                <?php echo e($sections->links()); ?>

                <p>
                    <?php echo e(trans('applang.showing')); ?>

                    <?php echo e(count($sections)); ?>

                    <?php echo e(trans('applang.from_original')); ?>

                    <?php echo e(count(\App\Models\ERP\Settings\Products\Section::all())); ?>

                    <?php echo e(trans('applang.entries')); ?>

                </p>
            </div>
        </div>


    </div>
    <?php echo $__env->make('erp.settings.products.sections.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/erp/products-settings/sections.blade.php ENDPATH**/ ?>