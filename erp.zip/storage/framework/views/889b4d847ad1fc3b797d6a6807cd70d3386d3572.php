<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('vendor-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/pages/authentication.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- forgot password start -->
<section class="row flexbox-container">
    <div class="col-xl-7 col-md-9 col-10  px-0">
        <div class="card bg-authentication mb-0">
            <div class="row m-0">
                <!-- left section-forgot password -->
                <div class="col-md-6 col-12 px-0">
                    <div class="card disable-rounded-right mb-0 p-2">
                        <div class="card-header pb-1">
                            <div class="card-title">
                                <h4 class="text-center mb-2"><?php echo e(__('Reset Password')); ?></h4>
                            </div>
                        </div>
                        <div class="form-group d-flex justify-content-between align-items-center mb-2">
                            <div class="text-left">
                                <div class="ml-3 ml-md-2 mr-1">
                                    <a href="<?php echo e(route('login')); ?>" class="card-link btn btn-outline-primary text-nowrap"><?php echo e(__('Login')); ?></a>
                                </div>
                            </div>
                            <div class="mr-3">
                                <a href="<?php echo e(route('register')); ?>" class="card-link btn btn-outline-primary text-nowrap"><?php echo e(__('Register')); ?></a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="text-muted text-center mb-2">
                                <small><?php echo e(__('Enter the email you used when you joined and we will send you password reset Link')); ?></small>
                            </div>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>

                            <form method="POST" action="<?php echo e(route('password.email')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group mb-2">
                                    <label class="text-bold-600" for="email"><?php echo e(__('Email Address')); ?></label>
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Email Address')); ?>" required autocomplete="email" autofocus>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <button type="submit" class="btn btn-primary glow position-relative w-100">
                                    <?php echo e(__('Send Password Reset Link')); ?> <i id="icon-arrow" class="bx bx-right-arrow-alt"></i>
                                </button>
                            </form>

                            <div class="text-center mb-2">
                                <a href="<?php echo e(route('login')); ?>">
                                    <small class="text-muted"><?php echo e(__('I remembered my password')); ?></small>
                                </a>
                            </div>

                            <div class="divider mb-2">
                                <div class="divider-text">Or Sign in as</div>
                            </div>
                            <div class="d-flex flex-md-row flex-column">
                                <a href="javascript:void(0);" class="btn btn-social btn-google btn-block font-small-3 mb-1 mb-sm-1 mb-md-0 mr-md-1 text-center">
                                    <i class="bx bxl-google font-medium-3"></i>
                                    <span class="pl-1">Google</span>
                                </a>
                                <a href="javascript:void(0);" class="btn btn-social btn-facebook btn-block font-small-3 text-center mt-0">
                                    <i class="bx bxl-facebook-square font-medium-3"></i>
                                    <span class="pl-1">Facebook</span>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- right section image -->
                <div class="col-md-6 d-md-block d-none text-center align-self-center">
                    <img class="img-fluid" src="<?php echo e(asset('app-assets')); ?>/images/pages/forgot-password.png" alt="branding logo" width="300">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- forgot password ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-vendor-js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>