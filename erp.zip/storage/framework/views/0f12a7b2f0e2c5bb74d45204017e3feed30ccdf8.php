<?php $__env->startSection('title', trans('applang.sequential_codes')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/pages/app-users.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
    <!--Datatables css-->
    <link rel="stylesheet" href="<?php echo e(asset('app-assets/cdns/css/datatables/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('app-assets/cdns/css/datatables/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('app-assets/cdns/css/datatables/buttons.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-body">
        <!-- users list start -->
        <section class="users-list-wrapper">
            <div class="default-app-list-table">
                <div class="card">
                    <div class="card-header justify-content-start">
                        <a href="<?php echo e(route('sequential-codes.create')); ?>" class="btn btn-success mb-0">
                            <i class="bx bx-user-plus"></i> <?php echo e(trans('applang.add')); ?>

                        </a>

                    </div>
                    <div class="card-body pt-1">
                        <!-- datatable start -->
                        <div class="table-responsive">
                            <table id="default-app-datatable" class="stripe hover bordered datatable datatable-codes" style="width: 100%">
                                <thead>
                                <tr>

                                    <th class="pl-2 no-wrap "><?php echo e(trans('applang.id')); ?></th>
                                    <th class="pl-10 no-wrap"><?php echo e(trans('applang.model')); ?></th>
                                    <th class="pl-10 no-wrap"><?php echo e(trans('applang.prefix')); ?></th>
                                    <th class="pl-10 no-wrap"><?php echo e(trans('applang.numbers_length')); ?></th>
                                    <td class="pl-10 no-wrap"><?php echo e(trans('applang.actions')); ?></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($seq_codes->count() > 0): ?>
                                    <?php $__currentLoopData = $seq_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seq_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="selected_row_<?php echo e($seq_code->id); ?>">


                                            <td class="normal-wrap pl-2 pr-2"><?php echo e($seq_code->id); ?></td>

                                            <td class="normal-wrap w-25">
                                                <a href="<?php echo e(route('sequential-codes.edit', $seq_code->id)); ?>"><?php echo e($seq_code->model); ?></a>
                                            </td>

                                            <td class="normal-wrap w-25">
                                                <?php echo e($seq_code->prefix); ?>

                                            </td>

                                            <td class="normal-wrap w-25">
                                                <?php echo e($seq_code->numbers_length); ?>

                                            </td>

                                            <td class="normal-wrap">
                                                <a  href="<?php echo e(route('sequential-codes.edit', $seq_code->id)); ?>" title="<?php echo e(trans('applang.edit')); ?>">
                                                    <i class="bx bx-edit-alt"></i>
                                                </a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- datatable ends -->
                    </div>
                </div>
            </div>
        </section>
        <!-- users list ends -->

    </div>




<?php $__env->stopSection(); ?>
<!-- END: Content-->

<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/datatables/datatable-filters.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/modal/components-modal.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>

    <!--Datatables js-->
    <script src="<?php echo e(asset('app-assets/cdns/js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/cdns/js/datatables/dataTables.responsive.min.js')); ?>"></script>


    <?php if(app()->getLocale() == 'ar'): ?>
        <script src="<?php echo e(asset("app-assets/js/scripts/datatables/datatable-rtl.js")); ?>"></script>
    <?php else: ?>
        <script src="<?php echo e(asset("app-assets/js/scripts/datatables/datatable.js")); ?>"></script>
    <?php endif; ?>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#formModalDeleteSeqCode').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget)
                var seq_code_id = button.data('seq_code_id')
                var prefix = button.data('prefix')
                var model = button.data('model')
                var modal = $(this)
                modal.find('.modal-body #seq_code_id').val(seq_code_id)
                modal.find('.modal-body #prefix').val(prefix)
                modal.find('.modal-body #model').val(model)
            });
        })

        <?php if(count($errors) > 0): ?>
        $('#formModal').modal('show');
        <?php endif; ?>

            <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/settings/sequential-codes/index.blade.php ENDPATH**/ ?>