<?php $__env->startSection('title', trans('applang.edit_supplier')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
    <link rel="stylesheet" href="<?php echo e(asset('app-assets/vendors/css/forms/select/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('app-assets/datepicker/css/bootstrap-datepicker3.standalone.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!--Start Update -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('suppliers.update', $supplier)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card">
                        <div class="card-header modal-header bg-primary">
                            <h4 class="modal-title white"><?php echo e(trans('applang.edit_supplier')); ?></h4>
                        </div>
                        <div class="card-body mt-1" style="padding-bottom: 13px">

                            <div class="row">
                                <div class="col-md-6">
                                    <!--Supplier Details-->
                                    <div class="custom-card mt-1 mb-5">
                                        <div class="card-header border-bottom" style="background-color: #f9f9f9">
                                            <span class="text-bold-700"><?php echo e(trans('applang.supplier_details')); ?></span>
                                        </div>

                                        <div class="card-body mt-1">

                                            <!--Commercial Name-->
                                            <label class="required" for="commercial_name"><?php echo e(trans('applang.commercial_name')); ?></label>
                                            <div class="position-relative has-icon-left mb-50">
                                                <input id="commercial_name"
                                                       type="text"
                                                       class="form-control <?php $__errorArgs = ['commercial_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="commercial_name"
                                                       placeholder="<?php echo e(trans('applang.commercial_name')); ?>"
                                                       autocomplete="commercial_name"
                                                       value="<?php echo e($supplier->commercial_name ?? old('commercial_name')); ?>"
                                                       autofocus>
                                                <div class="form-control-position">
                                                    <i class="bx bx-pen"></i>
                                                </div>
                                                <?php $__errorArgs = ['commercial_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>


                                            <!--First name & Last name-->
                                            <div class="form-row mb-50">
                                                <div class="col-md-6">
                                                    <label class="required" for="first_name"><?php echo e(trans('applang.first_name')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="first_name"
                                                               type="text"
                                                               class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="first_name"
                                                               placeholder="<?php echo e(trans('applang.first_name')); ?>"
                                                               autocomplete="first_name"
                                                               value="<?php echo e($supplier->first_name ?? old('first_name')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="required" for="last_name"><?php echo e(trans('applang.last_name')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="last_name"
                                                               type="text"
                                                               class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="last_name"
                                                               placeholder="<?php echo e(trans('applang.last_name')); ?>"
                                                               autocomplete="last_name"
                                                               value="<?php echo e($supplier->last_name ?? old('last_name')); ?>"
                                                        >
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--Country & State & City-->
                                            <div class="form-row mb-50">
                                                <div class="col-md-4">
                                                    <label class="required" for="country"><?php echo e(trans('applang.country')); ?></label>
                                                    <fieldset class="form-group">
                                                        <select id="country" class="custom-select <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='country'>
                                                            <option value="" selected disabled><?php echo e(trans('applang.select_country')); ?></option>
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option
                                                                    value="<?php echo e($key); ?>"
                                                                    <?php echo e($supplier->country == $key? 'selected' : ''); ?>>
                                                                    <?php echo e(app()->getLocale() == 'ar' ? $value['name'] : $value['en_name']); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                        <?php if($errors->has('country')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('country')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </fieldset>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="required" for="state"><?php echo e(trans('applang.state')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="state"
                                                               type="text"
                                                               class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="state"
                                                               placeholder="<?php echo e(trans('applang.state')); ?>"
                                                               autocomplete="state"
                                                               value="<?php echo e($supplier->state ?? old('state')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="required" for="city"><?php echo e(trans('applang.city')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="city"
                                                               type="text"
                                                               class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="city"
                                                               placeholder="<?php echo e(trans('applang.city')); ?>"
                                                               autocomplete="city"
                                                               value="<?php echo e($supplier->city ?? old('city')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                </div>
                                            </div>

                                            <!--Street Adress & Postal Code-->
                                            <div class="form-row mb-50">
                                                <div class="col-md-9">
                                                    <label class="required" for="street_address"><?php echo e(trans('applang.street_address')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="street_address"
                                                               type="text"
                                                               class="form-control <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="street_address"
                                                               placeholder="<?php echo e(trans('applang.street_address')); ?>"
                                                               autocomplete="street_address"
                                                               value="<?php echo e($supplier->street_address ?? old('street_address')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="postal_code"><?php echo e(trans('applang.postal_code')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="postal_code"
                                                               type="number"
                                                               class="form-control <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="postal_code"
                                                               placeholder="<?php echo e(trans('applang.postal_code')); ?>"
                                                               autocomplete="postal_code"
                                                               value="<?php echo e($supplier->postal_code ?? old('postal_code')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--Phone & Mobile-->
                                            <div class="form-row mb-50">
                                                <div class="col-md-6">
                                                    <label class="required" for="phone"><?php echo e(trans('applang.phone')); ?></label>
                                                    <div class="input-group" dir="ltr">
                                                        <div class="input-group-append" style="width: 20%">
                                                            <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                                   placeholder="&#9872; &#9743;" value="<?php echo e($supplier->phone_code ?? old('phone_code')); ?>">
                                                        </div>
                                                        <input id="phone"
                                                               type="number"
                                                               class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                                               name="phone"
                                                               placeholder="<?php echo e(trans('applang.phone')); ?>"
                                                               autocomplete="phone"
                                                               value="<?php echo e($supplier->phone ?? old('phone')); ?>"
                                                               autofocus>
                                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="mobile"><?php echo e(trans('applang.mobile')); ?></label>
                                                    <div class="input-group" dir="ltr">
                                                        <div class="input-group-append" style="width: 20%">
                                                            <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                                   placeholder="&#9872; &#9743;" value="<?php echo e($supplier->phone_code ?? old('phone_code')); ?>">
                                                        </div>
                                                        <input id="mobile"
                                                               type="number"
                                                               class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                                               name="mobile"
                                                               placeholder="<?php echo e(trans('applang.mobile')); ?>"
                                                               autocomplete="mobile"
                                                               value="<?php echo e($supplier->mobile ?? old('mobile')); ?>"
                                                               autofocus>
                                                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--Fax & Email-->
                                            <div class="form-row mb-50">
                                                <div class="col-md-6">
                                                    <label for="fax"><?php echo e(trans('applang.fax')); ?></label>
                                                    <div class="input-group" dir="ltr">
                                                        <div class="input-group-append" style="width: 20%">
                                                            <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                                   placeholder="&#9872; &#9743;" value="<?php echo e($supplier->phone_code ?? old('phone_code')); ?>">
                                                        </div>
                                                        <input id="fax"
                                                               type="number"
                                                               class="form-control <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                                               name="fax"
                                                               placeholder="<?php echo e(trans('applang.fax')); ?>"
                                                               autocomplete="fax"
                                                               value="<?php echo e($supplier->fax ?? old('fax')); ?>"
                                                               autofocus>
                                                        <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="email"><?php echo e(trans('applang.email')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="email"
                                                               type="email"
                                                               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="email"
                                                               placeholder="<?php echo e(trans('applang.email')); ?>"
                                                               autocomplete="email"
                                                               value="<?php echo e($supplier->email ?? old('email')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--Commercial Record & Tax Registration-->
                                            <div class="form-row mb-50">
                                                <div class="col-md-6">
                                                    <label for="commercial_record"><?php echo e(trans('applang.commercial_record')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="commercial_record"
                                                               type="text"
                                                               class="form-control <?php $__errorArgs = ['commercial_record'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="commercial_record"
                                                               placeholder="<?php echo e(trans('applang.commercial_record')); ?>"
                                                               autocomplete="commercial_record"
                                                               value="<?php echo e($supplier->commercial_record ?? old('commercial_record')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['commercial_record'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="tax_registration"><?php echo e(trans('applang.tax_registration')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="tax_registration"
                                                               type="text"
                                                               class="form-control <?php $__errorArgs = ['tax_registration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="tax_registration"
                                                               placeholder="<?php echo e(trans('applang.tax_registration')); ?>"
                                                               autocomplete="tax_registration"
                                                               value="<?php echo e($supplier->tax_registration ?? old('tax_registration')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['tax_registration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div id="supplier_contacts" class="mt-2">
                                                <h3  class="font-medium-4 font-weight-bolder hidden supplier_contacts_head"><?php echo e(trans('applang.contact_list')); ?></h3>
                                                <?php if($supplier->contacts->count() > 0): ?>
                                                    <?php $__currentLoopData = $supplier->contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <input type="hidden" value="<?php echo e($contact->id); ?>" name="contact_id[]">
                                                        <div class="supplier_contact_row">
                                                            <a class="btn btn-danger btn-xs remove-contact"
                                                               data-toggle="modal"
                                                               data-target="#formModalDeleteSupplierContact"
                                                               data-supplier_id="<?php echo e($supplier->id); ?>"
                                                               data-name="<?php echo e($contact->supp_cont_first_name); ?> <?php echo e($contact->supp_cont_last_name); ?>"
                                                               href="#">
                                                                <i class="bx bx-x"></i>
                                                            </a>
                                                            <div class="row">
                                                                <div class="col-md-6 col-xs-12 form-group">
                                                                    <label for="supp_cont_first_name"><?php echo e(trans('applang.first_name')); ?></label>
                                                                    <input name="supp_cont_first_name[]" type="text" value="<?php echo e($contact->supp_cont_first_name); ?>" class="form-control <?php $__errorArgs = ['supp_cont_first_name.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_first_name">
                                                                    <?php $__errorArgs = ['supp_cont_first_name.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="col-md-6 col-xs-12 form-group">
                                                                    <label for="supp_cont_last_name"><?php echo e(trans('applang.last_name')); ?></label>
                                                                    <input name="supp_cont_last_name[]" type="text" value="<?php echo e($contact->supp_cont_last_name); ?>" class="form-control <?php $__errorArgs = ['supp_cont_last_name.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_last_name">
                                                                    <?php $__errorArgs = ['supp_cont_last_name.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="supp_cont_email"><?php echo e(trans('applang.email')); ?></label>
                                                                <input name="supp_cont_email[]" type="email" value="<?php echo e($contact->supp_cont_email); ?>" class="form-control <?php $__errorArgs = ['supp_cont_email.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_email">
                                                                <?php $__errorArgs = ['supp_cont_email.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-6 col-xs-12 form-group">
                                                                    <label for="supp_cont_phone"><?php echo e(trans('applang.phone')); ?></label>
                                                                    <input name="supp_cont_phone[]" type="number" value="<?php echo e($contact->supp_cont_phone); ?>" class="form-control <?php $__errorArgs = ['supp_cont_phone.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_phone">
                                                                    <?php $__errorArgs = ['supp_cont_phone.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="col-md-6 col-xs-12 form-group">
                                                                    <label for="supp_cont_mobile"><?php echo e(trans('applang.mobile')); ?></label>
                                                                    <input name="supp_cont_mobile[]" type="number" value="<?php echo e($contact->supp_cont_mobile); ?>" class="form-control <?php $__errorArgs = ['supp_cont_mobile.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_mobile">
                                                                    <?php $__errorArgs = ['supp_cont_mobile.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                            <a href="javascript:void(0);" id="add_contact" class="btn btn-light-primary btn-sm">
                                                <i class="bx bx-plus"></i>
                                                <?php echo e(trans('applang.add_contact')); ?>

                                            </a>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <!--Account details-->
                                    <div class="custom-card mt-1 mb-5">
                                        <div class="card-header border-bottom" style="background-color: #f9f9f9">
                                            <span class="text-bold-700"><?php echo e(trans('applang.account_details')); ?></span>
                                        </div>

                                        <div class="card-body mt-1">
                                            <!--Supplier Code-->
                                            <label for="full_code"><?php echo e(trans('applang.full_code')); ?></label>
                                            <div class="position-relative has-icon-left mb-50">
                                                <input id="full_code"
                                                       type="text"
                                                       readonly
                                                       class="form-control"
                                                       value="<?php echo e($supplier->full_code); ?>"
                                                       autofocus>
                                                <div class="form-control-position">
                                                    <i class="bx bx-hash"></i>
                                                </div>
                                            </div>

                                            <!--Status-->
                                            <label class="required" for="status"><?php echo e(trans('applang.status')); ?></label>
                                            <fieldset class="form-group mb-50">
                                                <select id="status" class="custom-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='status'>
                                                    <option value="" selected disabled><?php echo e(trans('applang.status')); ?></option>
                                                    <option value="0" <?php echo e($supplier->status == 0 ? 'selected' : ''); ?>><?php echo e(trans('applang.suspended')); ?></option>
                                                    <option value="1" <?php echo e($supplier->status == 1 ? 'selected' : ''); ?>><?php echo e(trans('applang.active')); ?></option>
                                                </select>
                                                <?php if($errors->has('status')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('status')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </fieldset>

                                            <!--currency-->
                                            <label class="required" for="currency"><?php echo e(trans('applang.currency')); ?></label>
                                            <fieldset class="form-group mb-50">
                                                <div class="input-group-append">
                                                    <select id="currency" class="custom-select <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-currency" name='currency'>
                                                        <option value="" selected disabled><?php echo e(trans('applang.select_currency')); ?></option>
                                                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>" <?php echo e($supplier->currency == $key ? 'selected' : ''); ?>><?php echo e($value['name']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <input type="text" class="form-control text-append-currency-symbol basic-currency-symbol text-center" readonly name="currency_symbol"
                                                           placeholder="<?php echo e(trans('applang.symbol')); ?>" value="<?php echo e($supplier->currency_symbol ?? old('currency_symbol')); ?>" style="width:20%">
                                                </div>
                                                <?php if($errors->has('currency')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('currency')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </fieldset>

                                            <!--Opening balance & opening balance date-->
                                            <div class="form-row mb-50">
                                                <div class="col-md-6">
                                                    <label class="required" for="opening_balance"><?php echo e(trans('applang.opening_balance')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input id="opening_balance"
                                                               type="number"
                                                               class="form-control <?php $__errorArgs = ['opening_balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               name="opening_balance"
                                                               placeholder="<?php echo e(trans('applang.opening_balance')); ?>"
                                                               autocomplete="opening_balance"
                                                               value="<?php echo e($supplier->opening_balance ?? old('opening_balance')); ?>"
                                                               autofocus>
                                                        <div class="form-control-position">
                                                            <i class="bx bx-pen"></i>
                                                        </div>
                                                        <?php $__errorArgs = ['opening_balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="required" for="opening_balance_date"><?php echo e(trans('applang.opening_balance_date')); ?></label>
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text"
                                                               class="form-control <?php echo e(app()->getLocale() == 'ar' ? 'datepicker_ar' : 'datepicker_en'); ?> <?php $__errorArgs = ['opening_balance_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               placeholder="<?php echo e(trans('applang.select_date')); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>"
                                                               name="opening_balance_date"
                                                               value="<?php echo e($supplier->opening_balance_date); ?>"
                                                        >
                                                        <div class="form-control-position">
                                                            <i class="bx bx-calendar"></i>
                                                        </div>
                                                        <?php if($errors->has('opening_balance_date')): ?>
                                                            <span class="text-danger ">
                                                                <strong class="small font-weight-bolder"><?php echo e($errors->first('opening_balance_date')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--Notes-->
                                            <label for="currency"><?php echo e(trans('applang.notes')); ?></label>
                                            <fieldset class="form-group">
                                                <textarea name="notes" class="form-control" id="basicTextarea" rows="5" placeholder="<?php echo e(trans('applang.notes')); ?>">
                                                    <?php echo e($supplier->notes ?? old('notes')); ?>

                                                </textarea>
                                            </fieldset>

                                        </div>

                                    </div>
                                </div>
                            </div>

                            <hr class="hr modal-hr">
                            <div class="d-flex justify-content-end mt-2rem">
                                <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-light-secondary" data-dismiss="modal">
                                    <i class="bx bx-x d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.back_btn')); ?></span>
                                </a>
                                <button type="submit" class="btn btn-primary ml-1">
                                    <i class="bx bx-check d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--End Update Form -->

    <?php echo $__env->make('erp.purchases.suppliers.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/forms/select/select2.full.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>
    <!--DatePicker js-->
    <script src="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/locales/bootstrap-datepicker.ar.min.js" charset="UTF-8"></script>
    <script>
        $('.datepicker_ar').datepicker({
            format: "yyyy-mm-dd",
            maxViewMode: 3,
            todayBtn: "linked",
            clearBtn: true,
            orientation: "bottom auto",
            autoclose: true,
            todayHighlight: true,
            language: "ar",
        });

        $('.datepicker_en').datepicker({
            format: "yyyy-mm-dd",
            maxViewMode: 3,
            todayBtn: "linked",
            clearBtn: true,
            orientation: "bottom auto",
            autoclose: true,
            todayHighlight: true,
        });
    </script>
    <script type="text/javascript">
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
    <script>
        $(document).ready(function () {
            //get the country phone key
            $('#country').on('change', function () {
                var country = $(this).val()
                var url = "<?php echo e(url('/app-assets/data/countries_ar.json')); ?>"
                $.getJSON(url, function(data) {
                    $.map(data, function(value, key) {
                        if (key === country)
                        {
                            // console.log(value.phone_code)
                            $('.phone_code').val( '+ ' + value.phone_code)
                        }
                    });
                });
            });

            //get the basic currency symbol
            $('#currency').on('change', function () {
                var currency = $(this).val()
                var url = "<?php echo e(url('/app-assets/data/currency-symbols.json')); ?>"
                $.getJSON(url, function(data) {
                    $.map(data, function(value, key) {
                        if (key === currency)
                        {
                            // console.log(value.phone_code)
                            $('.basic-currency-symbol').val(value.symbol_native)
                        }
                    });
                });
            });
        });
    </script>
    <script>
        if($('.supplier_contact_row').length > 0){
            $('.supplier_contacts_head').removeClass('hidden');
        }
        $('#add_contact').on('click',function(e) {
            $('.supplier_contacts_head').removeClass('hidden');
            var row =
                '<div class="supplier_contact_row">' +
                '<input type="hidden" value="" name="contact_id[]">'+
                '<a class="btn btn-danger btn-xs remove-item remove-contact" href="javascript:void(0)"><i class="bx bx-x"></i></a>' +
                '<div class="row">' +
                '<div class="col-md-6 col-xs-12 form-group">' +
                '<label for="supp_cont_first_name"><?php echo e(trans('applang.first_name')); ?></label>' +
                '<input name="supp_cont_first_name[]" type="text" class="form-control <?php $__errorArgs = ["supp_cont_first_name.*"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_first_name">' +
                '<?php $__errorArgs = ['supp_cont_first_name.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>'+
                '<span class="invalid-feedback" role="alert">'+
                '<strong><?php echo e($message); ?></strong>'+
                '</span>'+
                '<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'+
                '</div>' +
                '<div class="col-md-6 col-xs-12 form-group">' +
                '<label for="supp_cont_last_name"><?php echo e(trans('applang.last_name')); ?></label>' +
                '<input name="supp_cont_last_name[]" type="text" class="form-control <?php $__errorArgs = ["supp_cont_last_name.*"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_last_name">' +
                '<?php $__errorArgs = ['supp_cont_last_name.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>'+
                '<span class="invalid-feedback" role="alert">'+
                '<strong><?php echo e($message); ?></strong>'+
                '</span>'+
                '<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'+
                '</div>' +
                '</div>' +
                '<div class="form-group">' +
                '<label for="supp_cont_email"><?php echo e(trans('applang.email')); ?></label>' +
                '<input name="supp_cont_email[]" type="email" class="form-control <?php $__errorArgs = ["supp_cont_email.*"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_email">' +
                '<?php $__errorArgs = ['supp_cont_email.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>'+
                '<span class="invalid-feedback" role="alert">'+
                '<strong><?php echo e($message); ?></strong>'+
                '</span>'+
                '<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'+
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-6 col-xs-12 form-group">' +
                '<label for="supp_cont_phone"><?php echo e(trans('applang.phone')); ?></label>' +
                '<input name="supp_cont_phone[]" type="number" class="form-control <?php $__errorArgs = ["supp_cont_phone.*"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_phone">' +
                '<?php $__errorArgs = ['supp_cont_phone.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>'+
                '<span class="invalid-feedback" role="alert">'+
                '<strong><?php echo e($message); ?></strong>'+
                '</span>'+
                '<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'+
                '</div>' +
                '<div class="col-md-6 col-xs-12 form-group">' +
                '<label for="supp_cont_mobile"><?php echo e(trans('applang.mobile')); ?></label>' +
                '<input name="supp_cont_mobile[]" type="number" class="form-control <?php $__errorArgs = ["supp_cont_mobile.*"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supp_cont_mobile">' +
                '<?php $__errorArgs = ['supp_cont_mobile.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>'+
                '<span class="invalid-feedback" role="alert">'+
                '<strong><?php echo e($message); ?></strong>'+
                '</span>'+
                '<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'+
                '</div>' +
                '</div>' +
                '</div>';
            $('#supplier_contacts').append(row);
        });

        $('body').on('click', '.remove-item', function (e){
            $(this).closest('.supplier_contact_row').remove();
            if($('.supplier_contact_row').length === 0){
                $('.supplier_contacts_head').addClass('hidden');
            }
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#formModalDeleteSupplierContact').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget)
                var supplier_id = button.data('supplier_id')
                var name = button.data('name')
                var modal = $(this)
                modal.find('.modal-body #supplier_id').val(supplier_id)
                modal.find('.modal-body #name').val(name)
            });
        })
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/purchases/suppliers/edit.blade.php ENDPATH**/ ?>