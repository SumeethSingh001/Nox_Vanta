<?php $__env->startSection('title', trans('applang.show_product')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="content-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('erp.inventory.show-product', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('prcQirm')) {
    $componentId = $_instance->getRenderedChildComponentId('prcQirm');
    $componentTag = $_instance->getRenderedChildComponentTagName('prcQirm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('prcQirm');
} else {
    $response = \Livewire\Livewire::mount('erp.inventory.show-product', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('prcQirm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>

    <!-- Warehouses Modals -->
    <?php echo $__env->make('erp.inventory.warehouses.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<!-- END: Content-->

<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/modal/components-modal.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>

    <script type="text/javascript">
/*        $(document).ready(function () {
            $('#formModalDeleteWarehouse').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget)
                var warehouse_id = button.data('warehouse_id')
                var name = button.data('name')
                var modal = $(this)
                modal.find('.modal-body #warehouse_id').val(warehouse_id)
                modal.find('.modal-body #name').val(name)
            });
        })*/

        <?php if(count($errors) > 0): ?>
        $('#formModal').modal('show');
        <?php endif; ?>

        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.options =
                {
                    "closeButton" : true,
                    "progressBar" : true,
                    "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
                }
                toastr.error("<?php echo e($error); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/inventory/products/show.blade.php ENDPATH**/ ?>