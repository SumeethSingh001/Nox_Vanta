<!DOCTYPE html>
<html class="loading"
        data-textdirection="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>"
        lang="<?php echo e(app()->getLocale()); ?>"
        dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="Frest admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, Frest admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="apple-touch-icon" href="<?php echo e(asset('app-assets')); ?>/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('app-assets')); ?>/images/ico/favicon.png">
    

    <?php if(app()->getLocale() == 'ar'): ?>
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800;900&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <?php else: ?>
        
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&display=swap" rel="stylesheet">
    <?php endif; ?>

    <?php if(app()->getLocale() == 'ar'): ?>
        <?php echo $__env->make('layouts.admin.partials.styles-rtl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('layouts.admin.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->
<body class="vertical-layout vertical-menu-modern semi-dark-layout 2-columns navbar-sticky footer-static
            <?php if(LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>arabic <?php else: ?> english <?php endif; ?>"
            data-open="click"
            data-menu="vertical-menu-modern"
            data-col="2-columns"
            data-layout="semi-dark-layout">

    <?php echo $__env->make('layouts.admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">

            <div class="content-header row">
                <?php if(isset($breadcrumbs)): ?>
                    <?php echo $__env->make('layouts/admin/partials/breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>

            <!-- Start Page Content -->
                <?php echo $__env->yieldContent('content'); ?>
            <!-- End Page Content -->

        </div>
    </div>
    <!-- END: Content-->


    <?php echo $__env->make('layouts.admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.admin.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/layouts/admin/admin_layout.blade.php ENDPATH**/ ?>