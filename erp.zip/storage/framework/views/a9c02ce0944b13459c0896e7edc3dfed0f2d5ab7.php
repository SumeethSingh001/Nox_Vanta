<!--Start ِAdd Section Modal -->
<div class="modal fade text-left closeModal" id="formModalAddSection" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h4 class="modal-title white" id="myModalLabel17"><?php echo e(trans('applang.add_section')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="bx bx-x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form wire:submit.prevent="store" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $addMore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $more): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="form-row">
                            <div class="col-sm-9">
                                <div class="form-group mb-50">
                                    <label class="required" for="name"><?php echo e(trans('applang.name')); ?></label>
                                    <div class="position-relative has-icon-left">
                                        <input type="text"
                                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               placeholder="<?php echo e(trans('applang.name')); ?>"
                                               autocomplete="name"
                                               value="<?php echo e(old('name')); ?>"
                                               autofocus
                                               wire:model="name.<?php echo e($more); ?>">
                                        <div class="form-control-position">
                                            <i class="bx bx-pen"></i>
                                        </div>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex align-items-end custom-control custom-switch col-sm-1" data-toggle="tooltip" data-placement="top" title="status">
                                <div class="form-group mb-50">
                                    <label class=""><?php echo e(trans('applang.status')); ?></label>
                                    <input type="checkbox" class="custom-control-input" id="status.<?php echo e($more); ?>" wire:model="status.<?php echo e($more); ?>">
                                    <label class="custom-control-label" for="status.<?php echo e($more); ?>"></label>
                                </div>
                            </div>

                            <div class="col-sm-2 d-flex align-items-end mb-50">
                                <button class="btn btn-light-success btn-xs pl-1 pr-1" wire:ignore wire:click.prevent="AddMore">
                                    <i class="bx bx-plus"></i>
                                </button>
                                <?php if($loop->index > 0): ?>
                                    <button class="btn btn-light-danger btn-xs mr-1 ml-1 pl-1 pr-1" wire:ignore wire:click.prevent="Remove(<?php echo e($loop->index); ?>)">
                                        <i class="bx bx-x"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>


                    <hr class="hr modal-hr">
                    <div class="d-flex justify-content-end mt-3">
                        <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block"><?php echo e(trans('applang.close_btn')); ?></span>
                        </button>
                        <button type="submit" class="btn btn-primary ml-1">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--End Add Section Modal -->

<!--Start Edit Section Modal -->
<div class="modal fade text-left closeModal forceClose" id="formModalEditSection" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h4 class="modal-title white" id="myModalLabel17"><?php echo e(trans('applang.edit_section')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="bx bx-x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form wire:submit.prevent="update" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-sm-9">
                            <div class="form-group mb-50">
                                <label class="required" for="name"><?php echo e(trans('applang.name')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input type="text"
                                           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="<?php echo e(trans('applang.name')); ?>"
                                           autocomplete="name"
                                           value="<?php echo e(old('name')); ?>"
                                           autofocus
                                           wire:model="name">
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex align-items-end custom-control custom-switch col-sm-1" data-toggle="tooltip" data-placement="top" title="status">
                            <div class="form-group mb-50">
                                <label class=""><?php echo e(trans('applang.status')); ?></label>
                                <input type="checkbox" class="custom-control-input" id="status" wire:model="status">
                                <label class="custom-control-label" for="status"></label>
                            </div>
                        </div>

                    </div>

                    <hr class="hr modal-hr">
                    <div class="d-flex justify-content-end mt-3">
                        <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block"><?php echo e(trans('applang.close_btn')); ?></span>
                        </button>
                        <button type="submit" class="btn btn-primary ml-1">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--End Edit Section Modal -->

<?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/settings/products/sections/modals.blade.php ENDPATH**/ ?>