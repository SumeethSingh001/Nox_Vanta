<?php $__env->startSection('title', trans('applang.branch_edit')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!--Start Update -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header modal-header bg-primary">
                        <h4 class="modal-title white"><?php echo e(trans('applang.branch_edit')); ?></h4>
                    </div>
                    <div class="card-body mt-1" style="padding-bottom: 13px">
                        <form action="<?php echo e(route('branches.update', $branch)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('erp.edit-branch-translation')->html();
} elseif ($_instance->childHasBeenRendered('VL3Z9gK')) {
    $componentId = $_instance->getRenderedChildComponentId('VL3Z9gK');
    $componentTag = $_instance->getRenderedChildComponentTagName('VL3Z9gK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VL3Z9gK');
} else {
    $response = \Livewire\Livewire::mount('erp.edit-branch-translation');
    $html = $response->html();
    $_instance->logRenderedChild('VL3Z9gK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                            <div class="form-group col-md-12 mb-50">
                                <label class="required" for="name_ar"><?php echo e(trans('applang.name_ar')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="name_ar"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['name_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="name_ar"
                                           placeholder="<?php echo e(trans('applang.name_ar')); ?>"
                                           autocomplete="name_ar"
                                           value="<?php echo e(isset($translated_name_ar) ? $translated_name_ar : $branch->name_ar); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bxs-lock"></i>
                                    </div>
                                    <?php $__errorArgs = ['name_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group col-md-12 mb-50">
                                <label class="required" for="name_en"><?php echo e(trans('applang.name_en')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="name_en"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="name_en"
                                           placeholder="<?php echo e(trans('applang.name_en')); ?>"
                                           autocomplete="name_en"
                                           value="<?php echo e(isset($translated_name_en) ? $translated_name_en : $branch->name_en); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bxs-lock"></i>
                                    </div>
                                    <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group col-md-12 mb-50">
                                <label class="required" for="address_ar"><?php echo e(trans('applang.address_ar')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="address_ar"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['address_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="address_ar"
                                           placeholder="<?php echo e(trans('applang.address_ar')); ?>"
                                           autocomplete="address_ar"
                                           value="<?php echo e(isset($translated_address_ar) ? $translated_address_ar : $branch->address_ar); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bxs-lock"></i>
                                    </div>
                                    <?php $__errorArgs = ['address_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group col-md-12 mb-50">
                                <label class="required" for="address_en"><?php echo e(trans('applang.address_en')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="address_en"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['address_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="address_en"
                                           placeholder="<?php echo e(trans('applang.address_en')); ?>"
                                           autocomplete="address_en"
                                           value="<?php echo e(isset($translated_address_en) ? $translated_address_en : $branch->address_en); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bxs-lock"></i>
                                    </div>
                                    <?php $__errorArgs = ['address_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>



                            <hr class="hr modal-hr">
                            <div class="d-flex justify-content-end mt-2rem">
                                <a href="<?php echo e(route('branches.index')); ?>" class="btn btn-light-secondary" data-dismiss="modal">
                                    <i class="bx bx-x d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.back_btn')); ?></span>
                                </a>
                                <button type="submit" class="btn btn-primary ml-1">
                                    <i class="bx bx-check d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--End Update Form -->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/forms/select/select2.full.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>
    <script>
        $(document).ready(function () {
            if (window.location.href.indexOf("translated") > -1) {
                $("#transBtn").attr("style", "display: none");
            }
        });
    </script>
    <script type="text/javascript">
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/branches/edit.blade.php ENDPATH**/ ?>