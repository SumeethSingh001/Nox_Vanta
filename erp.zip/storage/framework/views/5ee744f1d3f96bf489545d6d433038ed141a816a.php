<?php $__env->startSection('title', trans('applang.create_product')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="content-body">
            <div class="col-md-12">
                <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('erp.inventory.create-product')->html();
} elseif ($_instance->childHasBeenRendered('TJIVYLw')) {
    $componentId = $_instance->getRenderedChildComponentId('TJIVYLw');
    $componentTag = $_instance->getRenderedChildComponentTagName('TJIVYLw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TJIVYLw');
} else {
    $response = \Livewire\Livewire::mount('erp.inventory.create-product');
    $html = $response->html();
    $_instance->logRenderedChild('TJIVYLw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </form>
            </div>

        </div>
    </div>

    <!-- Warehouses Modals -->
    <?php echo $__env->make('erp.inventory.warehouses.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<!-- END: Content-->

<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/modal/components-modal.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>

    <script type="text/javascript">
        <?php if(count($errors) > 0): ?>
        $('#formModal').modal('show');
        <?php endif; ?>

            <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
    <script>
        $(document).ready(function (){
            //reset logo image
            $('.remove-logo').on('click', function(e) {
                e.preventDefault();
                $('#blah').attr('src', '<?php echo e(asset('/uploads/products/images/defaultProduct.jpg')); ?>');
                $('#blah').hide();
                $('#blah').fadeIn(500);
                $('.custom-file-label').text('defaultProduct.jpg');
                $("#inputGroupFile01").val();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/inventory/products/create.blade.php ENDPATH**/ ?>