<div>
    <div class="form-group col-md-12 mb-50">
        <label class="required" for="name"><?php echo e(trans('applang.name')); ?></label>
        <div class="position-relative has-icon-left">
            <input id="name"
                   type="text"
                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   name="name"
                   placeholder="<?php echo e(trans('applang.name')); ?>"
                   autocomplete="name"
                   value="<?php echo e(old('name')); ?>"
                   autofocus
                   wire:model='name'>
            <div class="form-control-position">
                <i class="bx bxs-lock"></i>
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-12 mb-50">
        <label class="required" for="address"><?php echo e(trans('applang.address')); ?></label>
        <div class="position-relative has-icon-left">
            <input id="address"
                   type="text"
                   class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   name="address"
                   placeholder="<?php echo e(trans('applang.address')); ?>"
                   autocomplete="address"
                   value="<?php echo e(old('address')); ?>"
                   autofocus
                   wire:model='address'>
            <div class="form-control-position">
                <i class="bx bxs-lock"></i>
            </div>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <a class="btn btn-warning m-1" href="<?php echo e(route('translateBranch', $name && $address ? ['name'=>$name, 'address'=>$address] : ['name' => 'test', 'address' => 'test'])); ?>">
        <i class="fas fa-language"></i>
        <?php echo e(trans('applang.translate')); ?>

    </a>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/erp/create-branch-translation.blade.php ENDPATH**/ ?>