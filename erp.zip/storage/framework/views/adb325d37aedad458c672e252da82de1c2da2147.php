<?php $__env->startSection('title', trans('applang.departments')); ?>

<?php $__env->startSection('vendor-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/pickers/pickadate/pickadate.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/pages/app-users.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
<!--Datatables css-->
<link rel="stylesheet" href="<?php echo e(asset('app-assets/cdns/css/datatables/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('app-assets/cdns/css/datatables/responsive.dataTables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('app-assets/cdns/css/datatables/buttons.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- users list start -->
    <section class="users-list-wrapper">
        <div class="default-app-list-table">
            <div class="card">
                <div class="card-header justify-content-start">
                    <a href="<?php echo e(route('perm_categories.create')); ?>" class="btn btn-success mb-0">
                        <i class="bx bx-user-plus"></i> <?php echo e(trans('applang.add')); ?>

                    </a>
                    <button type="button"
                            class="btn btn-primary mb-0 ml-1"
                            id="selectAllRecords">
                            <i class="bx bx-select-multiple"></i> <?php echo e(trans('applang.select_all')); ?>

                    </button>
                    <button type="button"
                            class="btn btn-primary mb-0 ml-1 disabled"
                            id="deselectAllSelectedRecords"
                            disabled>
                            <i class="bx bx-reset"></i> <?php echo e(trans('applang.deselect')); ?>

                    </button>
                    <button type="button"
                            class="btn btn-danger mb-0 mr-1 ml-1 disabled"
                            id="deleteAllSelectedRecords"
                            disabled>
                        <i class="bx bx-trash"></i> <?php echo e(trans('applang.delete_selected')); ?>

                    </button>
                </div>
                <div class="card-body pt-1">
                    <!-- datatable start -->
                    <div class="table-responsive">
                        <table id="default-app-datatable" class="stripe hover bordered datatable datatable-user" style="width: 100%">
                            <thead>
                                <tr>
                                    <th class="sorting_desc_disabled sorting_asc_disabled select_all no-wrap">
                                        <fieldset>
                                            
                                                <input type="checkbox" name="selectAllcheckbox" id="selectAllcheckbox" class="selectAllcheckbox">
                                                <label for="selectAllcheckbox"></label>
                                            
                                        </fieldset>
                                    </th>
                                    <th class="pl-10 no-wrap"><?php echo e(trans('applang.id')); ?></th>
                                    <th class="pl-10 no-wrap"><?php echo e(trans('applang.name')); ?></th>
                                    <th class="pl-10 no-wrap"><?php echo e(trans('applang.actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php if($categories->count() > 0): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="selected_row_<?php echo e($category->id); ?>">
                                            <td class="select_all normal-wrap">
                                                <fieldset>
                                                    
                                                        <input type="checkbox"
                                                                 name="itemId"
                                                                 id="<?php echo e($category->id); ?>"
                                                                 value="<?php echo e($category->id); ?>"
                                                                 class="selectItemCheckbox">
                                                        <label for="<?php echo e($category->id); ?>"></label>
                                                    
                                                </fieldset>
                                            </td>
                                            <td class="normal-wrap"><?php echo e($category->id); ?></td>
                                            <td class="normal-wrap w-50">
                                                <?php echo e(app()->getLocale() == 'ar' ? $category->name_ar : $category->name_en); ?>

                                            </td>
                                            <td class="normal-wrap">
                                                <a  href="<?php echo e(route('perm_categories.edit', $category->id)); ?>" title="<?php echo e(trans('applang.edit')); ?>">
                                                    <i class="bx bx-edit-alt"></i>
                                                </a>

                                                <a href="#"
                                                    title="<?php echo e(trans('applang.delete')); ?>"
                                                    class="text-danger mr-1 ml-1"
                                                    data-toggle="modal"
                                                    data-target="#formModalDeletePermissionCategory"
                                                    data-category_id="<?php echo e($category->id); ?>"
                                                    data-name_ar="<?php echo e($category->name_ar); ?>"
                                                    data-name_en="<?php echo e($category->name_en); ?>"
                                                    >
                                                    <i class="bx bx-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- datatable ends -->
                </div>
            </div>
        </div>
    </section>
    <!-- users list ends -->
</div>

<!-- users Modals -->
<?php echo $__env->make('admin.departments.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<!-- END: Content-->

<?php $__env->startSection('page-vendor-js'); ?>
<script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
<script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
<script src="<?php echo e(asset('app-assets')); ?>/vendors/js/forms/select/select2.full.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<script src="<?php echo e(asset('app-assets')); ?>/js/scripts/datatables/datatable-filters.js"></script>
<script src="<?php echo e(asset('app-assets')); ?>/js/scripts/modal/components-modal.js"></script>
<script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>
<script src="<?php echo e(asset('app-assets')); ?>/vendors/js/pickers/pickadate/picker.js"></script>
<script src="<?php echo e(asset('app-assets')); ?>/vendors/js/pickers/pickadate/picker.date.js"></script>
<script>
    // Basic date
    $('.pickadate').pickadate();
</script>
<!--Datatables js-->
<script src="<?php echo e(asset('app-assets/cdns/js/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/cdns/js/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/cdns/js/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/cdns/js/datatables/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/cdns/js/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/cdns/js/datatables/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/cdns/js/datatables/buttons.colVis.min.js')); ?>"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>

<script src="<?php echo e(asset('app-assets/cdns/js/datatables/jszip.min.js')); ?>"></script>
<?php if(app()->getLocale() == 'ar'): ?>
    <script src="<?php echo e(asset("app-assets/js/scripts/datatables/datatable-rtl.js")); ?>"></script>
<?php else: ?>
    <script src="<?php echo e(asset("app-assets/js/scripts/datatables/datatable.js")); ?>"></script>
<?php endif; ?>

<script type="text/javascript">
    $(document).ready(function () {
        $('#formModalDeletePermissionCategory').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget)
            var category_id = button.data('category_id')
            var name_ar = button.data('name_ar')
            var name_en = button.data('name_en')
            var modal = $(this)
            modal.find('.modal-body #category_id').val(category_id)
            modal.find('.modal-body #name_ar').val(name_ar)
            modal.find('.modal-body #name_en').val(name_en)
        });
    })

    $(function(e){
        var allTableIds = [];
        var allIds = [];

        //click select all button
        $('#selectAllRecords').click(function() {
            var all = $("input#selectAllcheckbox")[0];
            all.checked = true;
            var checked = all.checked;
            var table = $('#default-app-datatable').dataTable();
            $("input.selectItemCheckbox", table.fnGetNodes()).each(function () {
                $(this).prop("checked", checked);
                $(this).closest("tr").addClass("table-secondary");
                allTableIds.push($(this).val());
            });
            // allTableIds = jQuery.grep(allTableIds, function(value) {
            //     return value != <?php echo e(auth()->user()->id); ?>;
            // });
            console.log(allTableIds);
            allIds = allTableIds;
            $('#deleteAllSelectedRecords').removeClass('disabled');
            $('#deleteAllSelectedRecords').attr("disabled",false);
            $('#deselectAllSelectedRecords').removeClass('disabled');
            $('#deselectAllSelectedRecords').attr("disabled",false);
        });

        //click select all checkbox
        $('#selectAllcheckbox').click(function(){
            //check or uncheck all checkboxes of the tabel
            $('.selectItemCheckbox').prop('checked', $(this).prop('checked'));

            //get all table rows ids
            var table = $('#default-app-datatable').DataTable();
            var checked = this.checked;
            table.column(0).nodes().to$().each(function(index) {
                if (checked) {
                    $(this).find('input:checkbox[name=itemId]').prop('checked', true);
                    $(this).find('input:checkbox[name=itemId]').prop('checked', true).closest("tr").addClass("table-secondary");
                    allTableIds.push($(this).find('input:checkbox[name=itemId]').prop('checked', true).val());
                }else{
                    $(this).find('input:checkbox[name=itemId]').removeProp('checked');
                    $(this).find('input:checkbox[name=itemId]').prop('checked', false).closest("tr").removeClass("table-secondary");
                }
            });

            if ($('#selectAllcheckbox').prop('checked') == true) {
                $('#deleteAllSelectedRecords').removeClass('disabled');
                $('#deleteAllSelectedRecords').attr("disabled",false);
                allIds = allTableIds

                $('#deselectAllSelectedRecords').removeClass('disabled');
                $('#deselectAllSelectedRecords').attr("disabled",false);
            } else {
                allTableIds = [];
                $('#deleteAllSelectedRecords').addClass('disabled');
                $('#deleteAllSelectedRecords').attr("disabled",true);
                $("input:checkbox[name=itemId]").closest("tr").removeClass("table-secondary");

                $('#deselectAllSelectedRecords').addClass('disabled');
                $('#deselectAllSelectedRecords').attr("disabled",true);
            }

        });

        //check single row or uncheck single row after checking all table rows
        $("#default-app-datatable tbody").on('click', "input:checkbox[name=itemId]", function(e){
            if($(this).prop("checked") == true || $("input:checkbox:checked").length > 1){
                $(this).closest("tr").toggleClass("table-secondary");
                $('#deleteAllSelectedRecords').removeClass('disabled');
                $('#deleteAllSelectedRecords').attr("disabled",false);

                $('#deselectAllSelectedRecords').removeClass('disabled');
                $('#deselectAllSelectedRecords').attr("disabled",false);
            }else {
                $(this).closest("tr").toggleClass("table-secondary");
                $('#deleteAllSelectedRecords').addClass('disabled');
                $('#deleteAllSelectedRecords').attr("disabled",true);

                $('#deselectAllSelectedRecords').addClass('disabled');
                $('#deselectAllSelectedRecords').attr("disabled",true);
            }
        });


        //delete selected rows
        $('#deleteAllSelectedRecords').click(function(e){
            var selectedSingleRowsIds = []
            var table = $('#default-app-datatable').dataTable();
            //if select all table rows and then ucheck specific rows get the id of only checked
            if ($('#selectAllcheckbox').prop('checked') == true) {
                // allTableIds = jQuery.grep(allTableIds, function(value) {
                //     return value != <?php echo e(auth()->user()->id); ?>;
                // });
                allIds = allTableIds
                if($("input:checkbox:not(:checked)")){
                    $("input:checkbox:not(:checked)", table.fnGetNodes()).each(function(){
                        allTableIds.pop($(this).val())
                    });
                }
            } else {
                //if select single rows from the begining get its ids
                allTableIds = [];
                $("input:checkbox[name=itemId]:checked", table.fnGetNodes()).each(function(){
                    selectedSingleRowsIds.push($(this).val());
                    allIds = selectedSingleRowsIds
                });
            }

            console.log(allIds);

            var totalRecords = allIds.length;

            Swal.fire({
                title: '<?php echo e(trans("applang.swal_confirm")); ?>',
                text: "<?php echo e(trans('applang.swal_confirm_txt1')); ?> " + totalRecords +  " <?php echo e(trans('applang.swal_confirm_txt2')); ?>",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '<?php echo e(trans("applang.swal_confirm_btn")); ?>',
                cancelButtonText: '<?php echo e(trans("applang.swal_cancel_btn")); ?>',
            }).then((result) => {
                if(result.isConfirmed) {
                    $.ajax({
                        url:"<?php echo e(route('deleteSelectedPermissionsCategoies')); ?>",
                        type:"DELETE",
                        data:{
                            _token:$("input[name=_token]").val(),
                            ids:allIds
                        },
                        success:function(response){
                            $.each(allIds,function(key,val){
                                $("#selected_row_"+val).remove();
                            });
                            Swal.fire(
                                '<?php echo e(trans("applang.swal_deleted")); ?>',
                                '<?php echo e(trans("applang.swal_delete_success")); ?>',
                                'success'
                            );
                            setTimeout(function () {
                                location.reload();
                            }, 1000);
                        },
                    });

                } else if (result.dismiss === Swal.DismissReason.cancel || result.dismiss === Swal.DismissReason.backdrop){
                    Swal.fire(
                        '<?php echo e(trans("applang.swal_canceled")); ?>!',
                        '<?php echo e(trans("applang.swal_cancel_confirm")); ?>',
                        'error'
                    )
                    allTableIds = [];
                    selectedSingleRowsIds = [];
                    allIds = [];
                    $('.selectAllcheckbox').prop('checked', false);
                    $('#deleteAllSelectedRecords').addClass('disabled');
                    $('#deleteAllSelectedRecords').attr("disabled",true);
                    $('#deselectAllSelectedRecords').addClass('disabled');
                    $('#deselectAllSelectedRecords').attr("disabled",true);
                    var table = $('#default-app-datatable').DataTable();
                    var checked = this.checked;
                    table.column(0).nodes().to$().each(function(index) {
                        if (! checked) {
                            $(this).find('input:checkbox[name=itemId]').removeProp('checked');
                            $(this).find('input:checkbox[name=itemId]').prop('checked', false).closest("tr").removeClass("table-secondary");
                        }
                    });
                }
            });
        });

        //deselect all selected records
        $("#deselectAllSelectedRecords").click(function(e) {
            allTableIds = [];
            selectedSingleRowsIds = [];
            allIds = [];
            var table = $('#default-app-datatable').dataTable();
            if ($('#selectAllcheckbox').prop('checked') == true) {
                $("input:checkbox[name=itemId]:checked", table.fnGetNodes()).each(function(){
                        $(this).removeProp('checked');
                        $(this).prop('checked', false).closest("tr").removeClass("table-secondary");
                        $('#selectAllcheckbox').prop('checked', false);
                });
            } else {
                $("input:checkbox[name=itemId]:checked", table.fnGetNodes()).each(function(){
                    $(this).removeProp('checked');
                    $(this).prop('checked', false).closest("tr").removeClass("table-secondary");
                });
            }
            $('#deleteAllSelectedRecords').addClass('disabled');
            $('#deleteAllSelectedRecords').attr("disabled",true);
            $('#deselectAllSelectedRecords').addClass('disabled');
            $('#deselectAllSelectedRecords').attr("disabled",true);
        });

    });

    <?php if(count($errors) > 0): ?>
        $('#formModal').modal('show');
    <?php endif; ?>

    <?php if(Session::has('success')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
        }
  		toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
            toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/admin/departments/index.blade.php ENDPATH**/ ?>