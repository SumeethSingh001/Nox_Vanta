<div>
    <!-- Filters start-->
    <section class="users-list-wrapper">
        <div class="default-app-list-table">
            <div class="card">
                
                <div class="card-header justify-content-start">
                    <span class="text-bold-700 font-medium-1 text-black-50"><?php echo e(trans('applang.filters')); ?></span>
                </div>
                <div class="card-body pt-2 pb-0">
                    <div class="form-row">
                        <div class="col-md-6">
                            <input wire:model="search" type="text" class="form-control mb-50" placeholder="<?php echo e(trans('applang.search')); ?>">
                        </div>
                        <div class="col-md-6">

                            <div class="input-group input-daterange" id="bs-datepicker-daterange">
                                <input type="text"
                                       placeholder="<?php echo e(trans('applang.issue_date')); ?>"
                                       class="form-control <?php echo e(app()->getLocale() == 'ar' ? 'datepicker_ar' : 'datepicker_en'); ?> mb-50"
                                       wire:model="filterByIssueDateStart"
                                       onchange="this.dispatchEvent(new InputEvent('input'))"
                                       style="border-top-right-radius: 3px; border-bottom-right-radius: 3px; background-color: #FFFFFF" readonly>
                                <span class="input-group-text mb-50" style="border-radius: 0px"><?php echo e(trans('applang.to')); ?></span>
                                <input type="text"
                                       placeholder="<?php echo e(trans('applang.issue_date')); ?>"
                                       class="form-control <?php echo e(app()->getLocale() == 'ar' ? 'datepicker_ar' : 'datepicker_en'); ?> mb-50"
                                       wire:model="filterByIssueDateEnd"
                                       onchange="this.dispatchEvent(new InputEvent('input'))"
                                       style="border-top-left-radius: 3px; border-bottom-left-radius: 3px; background-color: #FFFFFF" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-md-3">
                            <select class="custom-select mb-50" wire:model="filterBySupplier">
                                <option value="" selected><?php echo e(trans('applang.select_supplier')); ?></option>
                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->commercial_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="custom-select mb-50" wire:model="filterByWarehouse">
                                <option value="" selected=""><?php echo e(trans('applang.select_warehouse')); ?></option>
                                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select wire:model="filterByReceivingStatus" class="custom-select mb-50">
                                <option selected value=""><?php echo e(trans('applang.select_receiving_status')); ?></option>
                                <option value="<?php echo e(1); ?>"><?php echo e(trans('applang.under_receive')); ?></option>
                                <option value="<?php echo e(2); ?>"><?php echo e(trans('applang.received')); ?></option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select wire:model="filterByPaymentStatus" class="custom-select mb-50">
                                <option selected value=""><?php echo e(trans('applang.select_payment_status')); ?></option>
                                <option value="<?php echo e(1); ?>"><?php echo e(trans('applang.unpaid')); ?></option>
                                <option value="<?php echo e(2); ?>"><?php echo e(trans('applang.partially_paid')); ?></option>
                                <option value="<?php echo e(3); ?>"><?php echo e(trans('applang.paid')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row mb-2">
                        <div class="col-md-3">
                            <select wire:model="sortAsc" class="custom-select mb-50">
                                <option selected><?php echo e(trans('applang.sort_by')); ?></option>
                                <option value="1"><?php echo e(trans('applang.ascending')); ?></option>
                                <option value="0"><?php echo e(trans('applang.descending')); ?></option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select wire:model="sortField" class="custom-select mb-50">
                                <option selected><?php echo e(trans('applang.sort_column')); ?></option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select wire:model="perPage" class="custom-select mb-50">
                                <option selected><?php echo e(trans('applang.per_page')); ?></option>
                                <option value="5">5</option>
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button wire:click.prevent="resetSearch" class="btn btn-primary w-100"><?php echo e(trans('applang.reset')); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- filters ends -->

    <!-- products list start -->
    <section class="users-list-wrapper">
        <div class="default-app-list-table">
            <div class="card">
                
                <div class="card-header justify-content-start">
                    <a href="<?php echo e(route('purchase-invoices.create')); ?>" class="btn btn-success mb-0 mr-1">
                        <i class="bx bx-plus"></i> <?php echo e(trans('applang.add')); ?>

                    </a>

                    <div class="btn-group">
                        <fieldset class="btn btn-bitbucket" style="padding: 4px 15px">
                            <label class="container-custom-checkbox">
                                <div class="d-flex justify-content-between align-content-center">
                                    <input type="checkbox" id="selectAll" wire:model="selectPage">
                                    <span class="checkmark"></span>
                                    <span class="checkbox-text"><?php echo e(trans('applang.select_all')); ?></span>
                                </div>
                            </label>
                        </fieldset>
                        <?php if(count($checked) > 0): ?>
                            <div class="btn-group">
                                <div class="dropdown">
                                    <button class="btn btn-danger dropdown-toggle rounded-0" type="button" id="dropdownMenuButton4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        (<span class="d-none d-sm-inline-block"><?php echo e(trans('applang.selected_rows_is')); ?></span> <?php echo e(count($checked)); ?>)
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton4" style="width: 100%">
                                        <a href="#" class="dropdown-item" wire:click.prevent="confirmBulkDelete()">
                                            <i class="bx bx-trash"></i>
                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.delete')); ?></span>
                                        </a>
                                        <a href="#" class="dropdown-item" wire:click.prevent="exportSelected()"
                                           onclick="confirm('<?php echo e(trans('applang.export_confirm_message')); ?>') || event.stopImmediatePropagation()">
                                            <i class="bx bxs-file-export"></i>
                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.export')); ?></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-info" wire:click.prevent="deselectSelected()">
                                <i class="bx bx-reset d-sm-inline-block"></i>
                                <span class="d-none d-sm-inline-block"><?php echo e(trans('applang.deselect')); ?></span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body pt-1 pb-1">
                    <?php if($selectPage): ?>
                        <div class="col-md-12 mb-2 pl-0 pr-0">
                            <div class="d-flex justify-content-start align-items-center">
                                <?php if($selectAll): ?>
                                    <div class="d-flex justify-content-start align-items-center">
                                        <p class="mb-0">
                                            <?php echo e(trans('applang.you_have_selected_all')); ?> ( <strong><?php echo e($purchaseInvoices->total()); ?></strong> <?php echo e(trans('applang.items')); ?> ).
                                        </p>
                                    </div>
                                <?php else: ?>
                                    <div class="d-flex justify-content-start align-items-center">
                                        <p class="mb-0">
                                            <?php echo e(trans('applang.you_have_selected')); ?> ( <strong><?php echo e(count($checked)); ?></strong> <?php echo e(trans('applang.items')); ?> ),
                                            <?php echo e(trans('applang.do_you_want_to_select_all')); ?> ( <strong><?php echo e($purchaseInvoices->total()); ?></strong> <?php echo e(trans('applang.items')); ?> ) ?
                                        </p>
                                        <a href="#" class="btn btn-sm btn-primary ml-1" wire:click="selectAll" title="<?php echo e(trans('applang.select_all')); ?>">
                                            <i class="bx bx-select-multiple d-sm-inline-block"></i>
                                            <span class="d-none d-sm-inline-block"><?php echo e(trans('applang.select_all')); ?></span>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <ul class="day-view-entry-list">
                        <?php $__currentLoopData = $purchaseInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $purchaseInvoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="day-view-entry product-index <?php echo e(in_array($purchaseInvoice->id ,$checked)? 'lightyellow' : ''); ?>">

                                <label class="checkbox-container" style="display: <?php echo e(in_array($purchaseInvoice->id ,$checked)? 'block' : ''); ?>">
                                    <input type="checkbox" class="product-input" value="<?php echo e($purchaseInvoice->id); ?>" wire:model="checked">
                                    <span class="checkmark"></span>
                                </label>

                                <div class="row align-items-center pr-2 pl-2">
                                    <div class="col-md-4">
                                        <div class="d-flex align-items-center">
                                            <a href="<?php echo e(route('purchase-invoices.show', $purchaseInvoice->id)); ?>" class="ml-1">
                                                <div class="project-client d-flex justify-content-start">
                                                    <div class="text-black-50">#<?php echo e($purchaseInvoice->inv_number); ?></div>
                                                    <div class="font-weight-bolder font-size-base black" style="margin-left: 5px; margin-right: 5px"><?php echo e($purchaseInvoice->issue_date); ?></div>
                                                </div>
                                                <div class="text-black-50 d-flex align-items-center">
                                                    <span class="text-black-50"><small>#<?php echo e($purchaseInvoice->supplier->full_code); ?></small></span>
                                                    <span class="font-weight-bolder font-size-base black" style="margin-right: 5px; margin-left: 5px"><?php echo e($purchaseInvoice->supplier->commercial_name); ?></span>
                                                </div>
                                                <div class="project-client">
                                                    <div class="font-weight-bolder font-size-base text-black-50">
                                                        <?php echo e($purchaseInvoice->supplier->street_address); ?>

                                                    </div>
                                                </div>
                                                <div class="text-black-50 d-flex align-items-center">
                                                    <span class="font-weight-bolder font-size-base">
                                                        <?php echo e($purchaseInvoice->supplier->city); ?>,
                                                        <?php echo e($purchaseInvoice->supplier->state); ?>,
                                                        <?php echo e($purchaseInvoice->supplier->country); ?>,
                                                        <?php echo e($purchaseInvoice->supplier->postal_code); ?>

                                                    </span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="d-flex justify-content-between">
                                            <div class="d-flex align-items-center" >
                                                <div class="text-center">
                                                    <div class="project-client">
                                                        <span class="font-weight-bolder font-size-base text-black-50"><?php echo e(trans('applang.created_in')); ?></span>
                                                        <span class="font-weight-bolder font-size-base text-black-50 d-flex justify-content-between align-items-center">
                                                            <small><i class="bx bx-time"></i></small>
                                                            <small class="font-weight-bolder text-black-50"><?php echo e($purchaseInvoice->created_at); ?></small>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center">
                                                <span class="font-weight-bolder black mb-50" style="font-size: 20px"><?php echo e($purchaseInvoice->total_inv . ' ' . $currency_symbol); ?></span>
                                                <?php if($purchaseInvoice->payment_status == 2): ?>
                                                    <?php if($purchaseInvoice->due_amount_after_payments > 0.00): ?>
                                                        <span class="d-block black" style="margin-top: 5px"><?php echo e(trans('applang.due_amount')); ?> : <?php echo e(number_format($purchaseInvoice->due_amount_after_payments, 0, '.', '')); ?> <?php echo e($currency_symbol); ?></span>
                                                    <?php elseif($purchaseInvoice->due_amount_after_payments == 0.00 && $purchaseInvoice->down_payment > 0): ?>
                                                        <span class="d-block black" style="margin-top: 5px"><?php echo e(trans('applang.due_amount')); ?> : <?php echo e($purchaseInvoice->due_amount); ?></span>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <div class="text-center" style="margin-top: 5px">
                                                    <?php if($purchaseInvoice->payment_status == 1): ?>
                                                        <span class="badge" style="background-color: red ; color: #FFFFFF"><?php echo e(trans('applang.unpaid')); ?></span>
                                                    <?php elseif($purchaseInvoice->payment_status == 2): ?>
                                                        <span class="badge" style="background-color: #ff7f00; color: #FFFFFF"><?php echo e(trans('applang.partially_paid')); ?></span>
                                                    <?php elseif($purchaseInvoice->payment_status == 3): ?>
                                                        <span class="badge badge-success-custom"><?php echo e(trans('applang.paid')); ?></span>
                                                    <?php endif; ?>

                                                    <?php if($purchaseInvoice->receiving_status == 1): ?>
                                                        <span class="badge" style="background-color: yellow; color: #333333" wire:model="receiving_status"><?php echo e(trans('applang.under_receive')); ?></span>
                                                    <?php elseif($purchaseInvoice->receiving_status == 2): ?>
                                                        <span class="badge badge-success-custom" wire:model="receiving_status"><?php echo e(trans('applang.received')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="dropdown" style="margin-right: 5px; margin-left: 5px">
                                                    <button class="btn btn-sm btn-light-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="bx bx-dots-horizontal-rounded"></i>
                                                    </button>
                                                    <div class="dropdown-menu <?php echo e(app()->getLocale() == 'ar' ? 'dropdown-menu-right': ''); ?>">
                                                        <a class="dropdown-item" href="<?php echo e(route('purchase-invoices.show', $purchaseInvoice->id)); ?>" title="<?php echo e(trans('applang.show')); ?>" >
                                                            <i class="bx bx-search"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.show')); ?></span>
                                                        </a>
                                                        <a class="dropdown-item" href="<?php echo e(route('purchase-invoices.edit', $purchaseInvoice->id)); ?>" title="<?php echo e(trans('applang.edit')); ?>" >
                                                            <i class="bx bx-edit-alt"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.edit')); ?></span>
                                                        </a>
                                                        <?php if($purchaseInvoice->receiving_status == 1 ): ?>
                                                            <a href="#" class="dropdown-item"  wire:click.prevent="receiptConfirmation(<?php echo e($purchaseInvoice->id); ?>)">
                                                                <i class="bx bx-check"></i>
                                                                <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.receipt_confirmation')); ?></span>
                                                            </a>
                                                        <?php endif; ?>
                                                        <a class="dropdown-item" href="<?php echo e(route('invoicePrint', $purchaseInvoice->id)); ?>" target="_blank" title="<?php echo e(trans('applang.print')); ?>" >
                                                            <i class="bx bx-printer"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.print')); ?></span>
                                                        </a>
                                                        <a class="dropdown-item" href="<?php echo e(route('invoicePDF', $purchaseInvoice->id)); ?>" target="_blank" title="PDF" >
                                                            <i class="bx bxs-file-pdf"></i>
                                                            <span class="font-weight-bold ml-1 mr-1">PDF</span>
                                                        </a>
                                                        <a class="dropdown-item" href="<?php echo e(route('sendToEmail', $purchaseInvoice->id)); ?>" title="<?php echo e(trans('applang.send_to_supplier')); ?>" >
                                                            <i class="bx bxs-envelope"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.send_to_supplier')); ?></span>
                                                        </a>
                                                        <a class="dropdown-item" href="#" title="<?php echo e(trans('applang.delete')); ?>"
                                                           wire:click.prevent="confirmDelete('<?php echo e($purchaseInvoice->id); ?>','<?php echo e($purchaseInvoice->inv_number); ?>')"
                                                        >
                                                            <i class="bx bx-trash"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.delete')); ?></span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="d-flex d-flex justify-content-between custom-pagination mt-1">
                        <?php echo $purchaseInvoices->links(); ?>

                        <p>
                            <?php echo e(trans('applang.showing')); ?>

                            <?php echo e(count($purchaseInvoices)); ?>

                            <?php echo e(trans('applang.from_original')); ?>

                            <?php echo e(count(\App\Models\ERP\Purchases\PurchaseInvoice::all())); ?>

                            <?php echo e(trans('applang.entries')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- products list ends -->
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/erp/purchases/purchase-invoices.blade.php ENDPATH**/ ?>