<?php $__env->startSection('title', trans('applang.sections')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('erp.products-settings.sections')->html();
} elseif ($_instance->childHasBeenRendered('CctiOZk')) {
    $componentId = $_instance->getRenderedChildComponentId('CctiOZk');
    $componentTag = $_instance->getRenderedChildComponentTagName('CctiOZk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CctiOZk');
} else {
    $response = \Livewire\Livewire::mount('erp.products-settings.sections');
    $html = $response->html();
    $_instance->logRenderedChild('CctiOZk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/settings/products/sections/index.blade.php ENDPATH**/ ?>