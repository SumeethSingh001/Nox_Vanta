<div class="card">
    <div class="card-header modal-header bg-primary">
        <h4 class="modal-title white"><?php echo e(trans('applang.edit_product')); ?></h4>
    </div>
    <div class="card-body mt-1" style="padding-bottom: 13px">
        <div class="row">
            <div class="col-md-6">
                <!--Product Details-->
                <div class="custom-card mt-1">
                    <div class="card-header bg-secondary bg-lighten-5 border-bottom" style="background-color: #f9f9f9">
                        <span class="text-bold-700 text-white"><?php echo e(trans('applang.product_details')); ?></span>
                    </div>

                    <div class="card-body mt-1">
                        <!--Product Name-->
                        <div class="form-row">
                            <div class="col-md-12">
                                <label class="required" for="name"><?php echo e(trans('applang.name')); ?></label>
                                <div class="position-relative has-icon-left mb-1">
                                    <input id="name"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="name"
                                           placeholder="<?php echo e(trans('applang.name')); ?>"
                                           autocomplete="name"
                                           value="<?php echo e($product->name ?? old('name')); ?>"
                                           autofocus
                                           wire:model="product_name">
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!--Product Description-->
                        <div class="form-row">
                            <div class="col-md-12">
                                <label class="required" for="description"><?php echo e(trans('applang.description')); ?></label>
                                <textarea
                                    class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mb-1"
                                    name="description"
                                    id="description"
                                    rows="5"
                                    placeholder="<?php echo e(trans('applang.description')); ?>">
                                    <?php echo e($product->description ?? old('description')); ?>

                                </textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!--Section & Brand-->
                        <div class="form-row mb-50">
                            <div class="col-md-6">
                                <label class="required" for="section_id"><?php echo e(trans('applang.section')); ?></label>
                                <fieldset class="form-group">
                                    <select id="section_id" class="custom-select <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='section_id' wire:model="section_id">
                                        <option value="" selected><?php echo e(trans('applang.select_section')); ?></option>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($section->id); ?>" <?php echo e($section->id == $product->section_id ? 'selected' : ''); ?>><?php echo e($section->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('section_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('section_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                            <div class="col-md-6">
                                <label class="required" for="brand_id"><?php echo e(trans('applang.brand')); ?></label>
                                <fieldset class="form-group">
                                    <select id="brand_id" class="custom-select <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='brand_id' wire:model="brand_id">
                                        <option value="" selected><?php echo e(trans('applang.select_brand')); ?></option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>" <?php echo e($brand->id == $product->brand_id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('brand_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('brand_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>

                        <!--Category & Subcategory-->
                        <div class="form-row mb-50">
                            <div class="col-md-6">
                                <label class="required" for="category_id"><?php echo e(trans('applang.category')); ?></label>
                                <fieldset class="form-group">
                                    <select id="category_id" class="custom-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='category_id' wire:model="category_id">
                                        <option value="" selected><?php echo e(trans('applang.select_the_category')); ?></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('category_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('category_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                            <div class="col-md-6">
                                <label class="required" for="subcategory_id"><?php echo e(trans('applang.sub_cat')); ?></label>
                                <fieldset class="form-group">
                                    <select id="brand_id" class="custom-select <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='subcategory_id' wire:model="subcategory_id">
                                        <option value="" selected><?php echo e(trans('applang.select_subcategory')); ?></option>
                                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subcategory->id); ?>" <?php echo e($subcategory->id == $product->subcategory_id ? 'selected' : ''); ?>><?php echo e($subcategory->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('subcategory_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('subcategory_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>

                        <!--Unit Template & Supplier-->
                        <div class="form-row mb-50">
                            <div class="col-md-6">
                                <label class="required" for="unit_template_id"><?php echo e(trans('applang.unit_template')); ?></label>
                                <fieldset class="form-group">
                                    <select id="unit_template_id" class="custom-select <?php $__errorArgs = ['unit_template_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='unit_template_id' wire:model="unit_template_id">
                                        <option value="" selected><?php echo e(trans('applang.select_unit_template')); ?></option>
                                        <?php $__currentLoopData = $units_templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($unit_template->id); ?>" <?php echo e($unit_template->id == $unit_template_id ? 'selected' : ''); ?>>
                                                <?php echo e(app()->getLocale() == 'ar' ? $unit_template->template_name_ar : $unit_template->template_name_en); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('unit_template_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('unit_template_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                            <div class="col-md-6">
                                <label class="required" for="supplier_id"><?php echo e(trans('applang.supplier')); ?></label>
                                <fieldset class="form-group">
                                    <select id="supplier_id" class="custom-select <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='supplier_id'>
                                        <option value="" selected disabled><?php echo e(trans('applang.select_supplier')); ?></option>
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($supplier->id); ?>" <?php echo e($supplier->id == $product->supplier_id ? 'selected' : ''); ?>><?php echo e($supplier->commercial_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('supplier_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('supplier_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>

                        <!--Lowest Stock Alert & Status-->
                        <div class="form-row mb-50">
                            <!--Lowest Stock Alert-->
                            <div class="col-md-6">
                                <label class="required" for="lowest_stock_alert"><?php echo e(trans('applang.lowest_stock_alert')); ?></label>
                                <div class="position-relative has-icon-left mb-1">
                                    <input id="lowest_stock_alert"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['lowest_stock_alert'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="lowest_stock_alert"
                                           placeholder="<?php echo e(trans('applang.lowest_stock_alert_placeholder')); ?>"
                                           autocomplete="lowest_stock_alert"
                                           value="<?php echo e($product->lowest_stock_alert ?? old('lowest_stock_alert')); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['lowest_stock_alert'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!--Status-->
                            <div class="col-md-6">
                                <label class="required" for="status"><?php echo e(trans('applang.status')); ?></label>
                                <fieldset class="form-group mb-50">
                                    <select id="status" class="custom-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='status'>
                                        <option value="" disabled><?php echo e(trans('applang.status')); ?></option>
                                        <option value="0" <?php echo e($supplier->status == '0' ? 'selected' : ''); ?>><?php echo e(trans('applang.suspended')); ?></option>
                                        <option value="1" <?php echo e($supplier->status == '1' ? 'selected' : ''); ?>><?php echo e(trans('applang.active')); ?></option>
                                    </select>
                                    <?php if($errors->has('status')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <!--Pricing details-->
                <div class="custom-card mt-1">
                    <div class="card-header bg-secondary bg-lighten-5 border-bottom" style="background-color: #f9f9f9">
                        <span class="text-bold-700 text-white"><?php echo e(trans('applang.pricing_details')); ?></span>
                    </div>

                    <div class="card-body mt-1">
                        <div class="form-row mb-50">
                            <!--Purchase Price-->
                            <div class="col-md-8">
                                <label class="required" for="purchase_price"><?php echo e(trans('applang.purchase_price')); ?></label>
                                <div class="position-relative has-icon-left mb-1">
                                    <input id="purchase_price"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="purchase_price"
                                           placeholder="<?php echo e(trans('applang.purchase_price')); ?>"
                                           autocomplete="purchase_price"
                                           value="<?php echo e($product->purchase_price ?? old('purchase_price')); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!--Measurement Unit-->
                            <div class="col-md-4">
                                <label class="required" for="measurement_unit_id"><?php echo e(trans('applang.measurement_unit')); ?></label>
                                <fieldset class="form-group">
                                    <select id="measurement_unit_id" class="custom-select <?php $__errorArgs = ['measurement_unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='measurement_unit_id' wire:model="measurement_unit_id">
                                        <option value="" selected><?php echo e(trans('applang.select_measurement_unit')); ?></option>
                                        <?php $__currentLoopData = $measurement_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement_unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($measurement_unit->id); ?>" <?php echo e($measurement_unit->id == $product->measurement_unit_id ? 'selected' : ''); ?>>
                                                <?php echo e(app()->getLocale() == 'ar' ? $measurement_unit->largest_unit_ar : $measurement_unit->largest_unit_en); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('measurement_unit_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('measurement_unit_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>

                        <div class="form-row mb-50">
                            <!--Sell Price-->
                            <div class="col-md-8">
                                <label class="required" for="sell_price"><?php echo e(trans('applang.sell_price')); ?></label>
                                <div class="position-relative has-icon-left mb-1">
                                    <input id="sell_price"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['sell_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="sell_price"
                                           placeholder="<?php echo e(trans('applang.sell_price')); ?>"
                                           autocomplete="sell_price"
                                           value="<?php echo e($product->sell_price ?? old('sell_price')); ?>"
                                           autofocus
                                           wire:model="product_sell_price">
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['sell_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!--Measurement Unit-->
                            <div class="col-md-4">
                                <label class="required" for="measurement_unit_id"><?php echo e(trans('applang.measurement_unit')); ?></label>
                                <fieldset class="form-group">
                                    <select id="measurement_unit_id" class="custom-select <?php $__errorArgs = ['measurement_unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='measurement_unit_id' wire:model="measurement_unit_id">
                                        <option value="" selected><?php echo e(trans('applang.select_measurement_unit')); ?></option>
                                        <?php $__currentLoopData = $measurement_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement_unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($measurement_unit->id); ?>" <?php echo e($measurement_unit->id == $product->measurement_unit_id ? 'selected' : ''); ?>>
                                                <?php echo e(app()->getLocale() == 'ar' ? $measurement_unit->largest_unit_ar : $measurement_unit->largest_unit_en); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('measurement_unit_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('measurement_unit_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>

                        <div class="form-row mb-50">
                            <!--First Tax-->
                            <div class="col-md-6">
                                <label class="required" for="first_tax_id"><?php echo e(trans('applang.first_tax')); ?></label>
                                <fieldset class="form-group">
                                    <select id="first_tax_id" class="custom-select <?php $__errorArgs = ['first_tax_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='first_tax_id'>
                                        <option value="" selected><?php echo e(trans('applang.select_first_tax')); ?></option>
                                        <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tax->id); ?>" <?php echo e($tax->id == $product->first_tax_id ? 'selected' : ''); ?>>
                                                <?php echo e($tax->tax_name_ar); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('first_tax_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('first_tax_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                            <!--Second Tax-->
                            <div class="col-md-6">
                                <label class="" for="second_tax_id"><?php echo e(trans('applang.second_tax')); ?></label>
                                <fieldset class="form-group">
                                    <select id="second_tax_id" class="custom-select <?php $__errorArgs = ['second_tax_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='second_tax_id'>
                                        <option value="" selected><?php echo e(trans('applang.select_second_tax')); ?></option>
                                        <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tax->id); ?>" <?php echo e($tax->id == $product->second_tax_id ? 'selected' : ''); ?>>
                                                <?php echo e($tax->tax_name_ar); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('second_tax_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('second_tax_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>

                        <div class="form-row mb-50">
                            <!--Lowest Sell Price-->
                            <div class="col-md-6">
                                <label class="required" for="lowest_sell_price"><?php echo e(trans('applang.lowest_sell_price')); ?></label>
                                <div class="position-relative has-icon-left mb-1">
                                    <input id="lowest_sell_price"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['lowest_sell_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="lowest_sell_price"
                                           placeholder="<?php echo e(trans('applang.lowest_sell_price')); ?>"
                                           autocomplete="lowest_sell_price"
                                           value="<?php echo e($product->lowest_sell_price ?? old('lowest_sell_price')); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['lowest_sell_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!--Profit Margin-->
                            <div class="col-md-6">
                                <label class="" for="profit_margin"><?php echo e(trans('applang.profit_margin_Percentage')); ?></label>
                                <div class="position-relative has-icon-left mb-1 input-group">
                                    <input id="profit_margin"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['profit_margin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="profit_margin"
                                           placeholder="<?php echo e(trans('applang.profit_margin_Percentage')); ?>"
                                           autocomplete="profit_margin"
                                           value="<?php echo e($product->profit_margin ?? old('profit_margin')); ?>"
                                           autofocus>
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-append-reset">%</span>
                                    </div>
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['profit_margin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                        </div>

                        <div class="form-row mb-50">
                            <!--Discount-->
                            <div class="col-md-6">
                                <label class="" for="sell_price"><?php echo e(trans('applang.discount')); ?></label>
                                <div class="position-relative has-icon-left mb-1">
                                    <input id="discount"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="discount"
                                           placeholder="<?php echo e(trans('applang.discount')); ?>"
                                           autocomplete="discount"
                                           value="<?php echo e($product->discount ?? old('discount')); ?>"
                                           autofocus>
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!--Discount Type-->
                            <div class="col-md-6">
                                <label class="" for="discount_type"><?php echo e(trans('applang.discount_type')); ?></label>
                                <fieldset class="form-group">
                                    <select id="discount_type" class="custom-select <?php $__errorArgs = ['discount_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='discount_type'>
                                        <option value="" selected disabled><?php echo e(trans('applang.select_discount_type')); ?></option>
                                        <option value="1" <?php echo e($product->discount_type == '1' ? 'selected' : ''); ?>><?php echo e(trans('applang.percentage')); ?></option>
                                        <option value="0" <?php echo e($product->discount_type == '0' ? 'selected' : ''); ?>><?php echo e(trans('applang.cash_amount')); ?></option>
                                    </select>
                                    <?php if($errors->has('discount_type')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('discount_type')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>

                        <div class="form-row mb-1">
                            <!--Notes-->
                            <label class="" for="notes"><?php echo e(trans('applang.notes')); ?></label>
                            <textarea
                                class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="notes"
                                id="notes"
                                rows="5"
                                placeholder="<?php echo e(trans('applang.notes')); ?>">
                                    <?php echo e($product->notes ?? old('notes')); ?>

                            </textarea>
                            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="row">
            <!--Inventory-->
            <div class="col-md-6">
                <div class="custom-card mt-1">
                    <div class="card-header bg-secondary bg-lighten-5 border-bottom" style="background-color: #f9f9f9">
                        <span class="text-bold-700 text-white"><?php echo e(trans('applang.sku_barcode')); ?></span>
                    </div>
                    <div class="card-body mt-1">
                        <!--SKU-->
                        <div class="form-row" style="margin-bottom: 21px">
                            <div class="col-md-12">
                                <label class="required" for="sku"><?php echo e(trans('applang.sku')); ?></label>
                                <div class="d-flex justify-content-start">
                                    <div class="position-relative has-icon-left w-100">
                                        <input type="text"
                                               class="form-control button-input <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="sku"
                                               placeholder="<?php echo e(trans('applang.generate_sku')); ?>"
                                               value="<?php echo e($product->sku); ?>"
                                               wire:model="product_sku"
                                               readonly>
                                        <div class="form-control-position">
                                            <i class="bx bx-barcode"></i>
                                        </div>
                                        <?php if($errors->has('sku')): ?>
                                            <span class="invalid-feedback position-absolute" role="alert">
                                                <strong><?php echo e($errors->first('sku')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="input-group-prepend generateSKU">
                                        <button class="btn btn-light-danger text-append-reset" wire:click.prevent="generateSKU(<?php echo e($product->id); ?>)">
                                            <i class="bx bx-analyse"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="col-md-12">
                                <label class="required" for="barcode"><?php echo e(trans('applang.barcode')); ?></label>
                                <div class="d-flex justify-content-center align-items-center product_barcode" wire:model="product_barcode">
                                    <?php if($product_barcode): ?>
                                        <div class="mt-2 custom-card p-1 bg-white">
                                            <div class="d-flex justify-content-between mb-0">
                                                <h6 class="d-flex justify-content-center mb-0" style="font-size: 14px">
                                                    <?php echo e($product_name); ?>

                                                </h6>
                                                <h6 class="d-flex justify-content-center mb-0" style="font-size: 14px">
                                                    <?php echo e($product_sell_price); ?> <?php echo e($currency_symbol); ?>

                                                </h6>
                                            </div>
                                            <div class="d-flex justify-content-center"><?php echo $product_barcode; ?></div>
                                            <h6 class="d-flex justify-content-center mb-0"><?php echo e($product_sku); ?></h6>
                                        </div>
                                    <?php else: ?>
                                        <h2 class="text-bold-600" style="color: #c5c5c5"><?php echo e(trans('applang.barcode_preview')); ?></h2>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--Product Image-->
            <div class="col-md-6">
                <div class="custom-card mt-1">
                    <div class="card-header bg-secondary bg-lighten-5 border-bottom" style="background-color: #f9f9f9">
                        <span class="text-bold-700 text-white"><?php echo e(trans('applang.product_image')); ?></span>
                    </div>
                    <div class="card-body mt-1">
                        <div class="form-row mb-50">
                            <div class="col-md-12 mb-50">
                                <div id='img_contain'>
                                    <img id="blah"
                                         align='middle'
                                         src="<?php echo e($product_image ? $product_image->temporaryUrl() : asset('uploads/products/images/'.$product->product_image)); ?>"
                                         alt="Product Image"
                                         title='Product Image'/>
                                </div>
                                <div class="input-group is-invalid">
                                    <div class="custom-file">
                                        <input type="file" id="inputGroupFile01" name="product_image" class="imgInp custom-file-input" wire:model="product_image">
                                        <label class="custom-file-label text-append-logo" for="inputGroupFile01">
                                            <?php echo e($product_image ? $product_image->getClientOriginalName() : trans('applang.choose_product_image')); ?>

                                        </label>
                                    </div>
                                    <a href="#" class="btn btn-light-info btn-sm remove-logo text-append-reset" title="<?php echo e(trans('applang.reset')); ?>">
                                        <i class="bx bx-reset"></i>
                                    </a>
                                </div>
                                <?php if($errors->has('product_image')): ?>
                                    <div class="invalid-feedback">
                                        <strong><?php echo e($errors->first('product_image')); ?></strong>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <hr class="hr modal-hr">
        <div class="d-flex justify-content-end mt-2rem">
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-light-secondary" data-dismiss="modal">
                <i class="bx bx-x d-block d-sm-none"></i>
                <span class="d-none d-sm-block"><?php echo e(trans('applang.back_btn')); ?></span>
            </a>
            <button type="submit" class="btn btn-primary ml-1">
                <i class="bx bx-check d-block d-sm-none"></i>
                <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
            </button>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/erp/inventory/edit-product.blade.php ENDPATH**/ ?>