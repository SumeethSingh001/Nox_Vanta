<div class="card">
    <div class="card-header modal-header bg-primary">
        <h4 class="modal-title white"><?php echo e(trans('applang.new_sales_invoice')); ?></h4>
    </div>

    <div class="card-body mt-1" style="padding-bottom: 13px">
        <div class="row">
            <!--Client Data-->
            <div class="col-md-6">
                <div class="input-group">
                    <div style="width: 85%">
                        <label class="required" for="client_id"><?php echo e(trans('applang.client')); ?></label>
                        <fieldset class="form-group">
                            <select id="client_id" class="custom-select <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-logo" name='client_id' wire:model="client_id">
                                <option value="" selected><?php echo e(trans('applang.select_client')); ?></option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->full_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('client_id')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('client_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </fieldset>
                    </div>
                    <a href="#"
                       class="btn btn-primary btn-sm text-append-reset" title="<?php echo e(trans('applang.add_new')); ?>"
                       style="width: 15%;height: fit-content;align-items: center;margin-top: 23px;line-height: 2;"
                       wire:click.prevent="showCreateClient">
                        <i class="bx bx-plus-circle"></i>
                    </a>
                </div>

                <!--create Client-->
                <div class="client-form" style="display: <?php echo e($showCreateClient == false ? 'none' : 'block'); ?>">
                    <form wire:submit.prevent="saveNewClient">
                        <!--Full Name-->
                        <label class="required" for="full_name"><?php echo e(trans('applang.full_name')); ?></label>
                        <div class="position-relative has-icon-left mb-50">
                            <input id="full_name"
                                   type="text"
                                   class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="full_name"
                                   placeholder="<?php echo e(trans('applang.full_name')); ?>"
                                   autocomplete="full_name"
                                   autofocus
                                   wire:model="full_name">
                            <div class="form-control-position">
                                <i class="bx bx-pen"></i>
                            </div>
                            <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!--Country-->
                        <label class="" for="country"><?php echo e(trans('applang.country')); ?></label>
                        <fieldset class="form-group">
                            <select id="country" class="custom-select <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='country' wire:model="country">
                                <option value=""><?php echo e(trans('applang.select_country')); ?></option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>">
                                        <?php echo e(app()->getLocale() == 'ar' ? $value['name'] : $value['en_name']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('country')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('country')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </fieldset>

                        <!--Phone & Mobile-->
                        <div class="form-row mb-50">
                            <div class="col-md-6">
                                <label class="" for="phone"><?php echo e(trans('applang.phone')); ?></label>
                                <div class="input-group" dir="ltr">
                                    <div class="input-group-append" style="width: 25%">
                                        <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                               placeholder="&#9872; &#9743;" wire:model="phone_code">
                                    </div>
                                    <input id="phone"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                           name="phone"
                                           placeholder="<?php echo e(trans('applang.phone')); ?>"
                                           autocomplete="phone"
                                           wire:model="phone"
                                    >
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="mobile"><?php echo e(trans('applang.mobile')); ?></label>
                                <div class="input-group" dir="ltr">
                                    <div class="input-group-append" style="width: 25%">
                                        <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                               placeholder="&#9872; &#9743;" value="<?php echo e(old('phone_code')); ?>" wire:model="phone_code">
                                    </div>
                                    <input id="mobile"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                           name="mobile"
                                           placeholder="<?php echo e(trans('applang.mobile')); ?>"
                                           autocomplete="mobile"
                                           wire:model="mobile"
                                    >
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!--Street Adress & Postal Code-->
                        <div class="form-row mb-50">
                            <div class="col-md-9">
                                <label class="" for="street_address"><?php echo e(trans('applang.street_address')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="street_address"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="street_address"
                                           placeholder="<?php echo e(trans('applang.street_address')); ?>"
                                           autocomplete="street_address"
                                           wire:model="street_address"
                                           >
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="postal_code"><?php echo e(trans('applang.postal_code')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="postal_code"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="postal_code"
                                           placeholder="<?php echo e(trans('applang.postal_code')); ?>"
                                           autocomplete="postal_code"
                                           wire:model="postal_code"
                                           >
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!--State & City-->
                        <div class="form-row mb-50">
                            <div class="col-md-6">
                                <label class="" for="state"><?php echo e(trans('applang.state')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="state"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="state"
                                           placeholder="<?php echo e(trans('applang.state')); ?>"
                                           autocomplete="state"
                                           wire:model="state"
                                           >
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="" for="city"><?php echo e(trans('applang.city')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="city"
                                           type="text"
                                           class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="city"
                                           placeholder="<?php echo e(trans('applang.city')); ?>"
                                           autocomplete="city"
                                           wire:model="city"
                                           >
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end mt-2rem">
                            <a href="" class="btn btn-light-secondary" wire:click.prevent="cancelCreateClient">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block"><?php echo e(trans('applang.cancel')); ?></span>
                            </a>
                            <button type="submit" class="btn btn-primary ml-1">
                                <i class="bx bx-check d-block d-sm-none"></i>
                                <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
                            </button>
                        </div>

                    </form>
                </div>

                <?php if($client_id): ?>
                    <!--Edit Client-->
                    <div class="client-form" style="display: <?php echo e($showEditClient == false ? 'none' : 'block'); ?>">
                        <form wire:submit.prevent="saveEditClient">
                            <!--Full Name-->
                            <label class="required" for="full_name"><?php echo e(trans('applang.full_name')); ?></label>
                            <div class="position-relative has-icon-left mb-50">
                                <input id="full_name"
                                       type="text"
                                       class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       name="full_name"
                                       placeholder="<?php echo e(trans('applang.full_name')); ?>"
                                       autocomplete="full_name"
                                       autofocus
                                       wire:model="full_name">
                                <div class="form-control-position">
                                    <i class="bx bx-pen"></i>
                                </div>
                                <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!--Country-->
                            <label class="" for="country"><?php echo e(trans('applang.country')); ?></label>
                            <fieldset class="form-group">
                                <select id="country" class="custom-select <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='country' wire:model="country">
                                    <option value=""><?php echo e(trans('applang.select_country')); ?></option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>">
                                            <?php echo e(app()->getLocale() == 'ar' ? $value['name'] : $value['en_name']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('country')): ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('country')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </fieldset>

                            <!--Phone & Mobile-->
                            <div class="form-row mb-50">
                                <div class="col-md-6">
                                    <label class="" for="phone"><?php echo e(trans('applang.phone')); ?></label>
                                    <div class="input-group" dir="ltr">
                                        <div class="input-group-append" style="width: 25%">
                                            <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                   placeholder="&#9872; &#9743;" value="<?php echo e(old('phone_code')); ?>" wire:model="phone_code">
                                        </div>
                                        <input id="phone"
                                               type="number"
                                               class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                               name="phone"
                                               placeholder="<?php echo e(trans('applang.phone')); ?>"
                                               autocomplete="phone"
                                               wire:model="phone"
                                        >
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="mobile"><?php echo e(trans('applang.mobile')); ?></label>
                                    <div class="input-group" dir="ltr">
                                        <div class="input-group-append" style="width: 25%">
                                            <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                   placeholder="&#9872; &#9743;" value="<?php echo e(old('phone_code')); ?>" wire:model="phone_code">
                                        </div>
                                        <input id="mobile"
                                               type="number"
                                               class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                               name="mobile"
                                               placeholder="<?php echo e(trans('applang.mobile')); ?>"
                                               autocomplete="mobile"
                                               wire:model="mobile"
                                        >
                                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <!--Street Adress & Postal Code-->
                            <div class="form-row mb-50">
                                <div class="col-md-9">
                                    <label class="" for="street_address"><?php echo e(trans('applang.street_address')); ?></label>
                                    <div class="position-relative has-icon-left">
                                        <input id="street_address"
                                               type="text"
                                               class="form-control <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="street_address"
                                               placeholder="<?php echo e(trans('applang.street_address')); ?>"
                                               autocomplete="street_address"
                                               wire:model="street_address">
                                        <div class="form-control-position">
                                            <i class="bx bx-pen"></i>
                                        </div>
                                        <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label for="postal_code"><?php echo e(trans('applang.postal_code')); ?></label>
                                    <div class="position-relative has-icon-left">
                                        <input id="postal_code"
                                               type="number"
                                               class="form-control <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="postal_code"
                                               placeholder="<?php echo e(trans('applang.postal_code')); ?>"
                                               autocomplete="postal_code"
                                               wire:model="postal_code">
                                        <div class="form-control-position">
                                            <i class="bx bx-pen"></i>
                                        </div>
                                        <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <!--State & City-->
                            <div class="form-row mb-50">
                                <div class="col-md-6">
                                    <label class="" for="state"><?php echo e(trans('applang.state')); ?></label>
                                    <div class="position-relative has-icon-left">
                                        <input id="state"
                                               type="text"
                                               class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="state"
                                               placeholder="<?php echo e(trans('applang.state')); ?>"
                                               autocomplete="state"
                                               wire:model="state">
                                        <div class="form-control-position">
                                            <i class="bx bx-pen"></i>
                                        </div>
                                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="" for="city"><?php echo e(trans('applang.city')); ?></label>
                                    <div class="position-relative has-icon-left">
                                        <input id="city"
                                               type="text"
                                               class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="city"
                                               placeholder="<?php echo e(trans('applang.city')); ?>"
                                               autocomplete="city"
                                               wire:model="city">
                                        <div class="form-control-position">
                                            <i class="bx bx-pen"></i>
                                        </div>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end mt-2rem">
                                <a href="" class="btn btn-light-secondary" wire:click.prevent="cancelEditClient">
                                    <i class="bx bx-x d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.cancel')); ?></span>
                                </a>
                                <button type="submit" class="btn btn-primary ml-1">
                                    <i class="bx bx-check d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
                                </button>
                            </div>

                        </form>
                    </div>

                    <!--Selected Client-->
                    <div class="supplier_invoice" style="border: 1px solid #00b0ef; background-color: #f6f9fc">
                        <div class="d-flex align-items-center">
                            <h4 class="font-weight-bold black"><?php echo e($clnt->full_name); ?></h4>
                            <a href="" id="editClient" class="font-size-small black font-weight-bold ml-50 mr-50" style="text-decoration: underline" wire:click.prevent="showEditClient">
                                <i class="bx bx-pencil font-size-base font-weight-bold"></i> <?php echo e(trans('applang.edit_details')); ?>

                            </a>
                        </div>
                        <?php if($clnt->street_address != null): ?>
                            <div class="d-flex mt-50">
                                <span class="font-weight-bold text-dark"><?php echo e(trans('applang.address')); ?>:</span>
                                <div class="ml-1 mr-1">
                                    <span style="display: block"><?php echo e($clnt->street_address); ?></span>
                                    <span style="display: block"><?php echo e($clnt->city); ?>, <?php echo e($clnt->state); ?>, <?php echo e($clnt->country); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </div>

            <!--Invoice number & Issue Date & Due Date-->
            <div class="col-md-6">
                <!--Invoice number-->
                <label class="required" for="inv_number"><?php echo e(trans('applang.purchase_invoice_number')); ?></label>
                <div class="position-relative has-icon-left mb-50">
                    <input id="inv_number"
                           type="text"
                           class="form-control <?php $__errorArgs = ['inv_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           name="inv_number"
                           placeholder="<?php echo e(trans('applang.purchase_invoice_number')); ?>"
                           autocomplete="inv_number"
                           value="<?php echo e($inv_number); ?>"
                           readonly>
                    <div class="form-control-position">
                        <i class="bx bx-pen"></i>
                    </div>
                </div>
                <!--Issue Date-->
                <label class="required" for="issue_date"><?php echo e(trans('applang.issue_date')); ?></label>
                <div class="position-relative has-icon-left mb-50">
                    <input type="text"
                           class="form-control <?php $__errorArgs = ['issue_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="<?php echo e(trans('applang.select_date')); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>"
                           name="issue_date"
                           value="<?php echo e(date('Y-m-d')); ?>"
                           readonly
                    >
                    <div class="form-control-position">
                        <i class="bx bx-calendar"></i>
                    </div>
                </div>
                <!--Due Date-->
                <label class="required" for="due_date"><?php echo e(trans('applang.due_date')); ?></label>
                <div class="position-relative has-icon-left">
                    <input type="text"
                           class="form-control <?php echo e(app()->getLocale() == 'ar' ? 'datepicker_ar' : 'datepicker_en'); ?> <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="<?php echo e(trans('applang.due_date')); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>"
                           name="due_date"
                           value="<?php echo e(date('Y-m-d')??old('due_date')); ?>"
                    >
                    <div class="form-control-position">
                        <i class="bx bx-calendar"></i>
                    </div>
                    <?php if($errors->has('due_date')): ?>
                        <span class="text-danger ">
                            <strong class="small font-weight-bolder"><?php echo e($errors->first('due_date')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <hr class="hr-dotted">

        <!--invoice table-->
        <div class="table-responsive">
            <table class="table table-small-font table-bordered inv-table" id="tax_table" style="width: 100%">
                <thead style="background-color: #f5f5f5;">
                <tr>
                    <td class="no-wrap inv-table-head"><?php echo e(trans('applang.item')); ?></td>
                    <td class="no-wrap inv-table-head"><?php echo e(trans('applang.description')); ?></td>
                    <td class="no-wrap inv-table-head"><?php echo e(trans('applang.unit_price')); ?></td>
                    <td class="no-wrap inv-table-head"><?php echo e(trans('applang.quantity')); ?></td>
                    <td class="no-wrap inv-table-head"><?php echo e(trans('applang.tax')); ?> 1</td>
                    <?php if(count($taxes) > 1): ?>
                        <td class="no-wrap inv-table-head"><?php echo e(trans('applang.tax')); ?> 2</td>
                    <?php endif; ?>
                    <td class="no-wrap inv-table-head"><?php echo e(trans('applang.total')); ?></td>
                    <td class="no-wrap inv-table-head"></td>
                </tr>
                </thead>
                <tbody>
                <!--Invoice Items Details-->
                <?php $__currentLoopData = $addProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $more): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <!--Products-->
                        <td style="width: 18%" class="pt-0 pb-0">
                            <div class="form-group col-md-12 mb-0 w-100">
                                <select id="product_id.<?php echo e($index); ?>"
                                        class="border-0 pl-0 pr-0 <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name='product_id[]' wire:model="addProduct.<?php echo e($index); ?>.product_id" style="outline: none; width: 100%">
                                    <option value="" selected></option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('product_id.'.$index)): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('product_id[]')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <!--Description-->
                        <td class="pt-0 pb-0" style="width: 18%">
                            <div class="form-group col-md-12 mb-0 w-100">
                                <div class="d-flex align-items-center">
                                        <textarea name="description[]"
                                                  id="description.<?php echo e($index); ?>"
                                                  cols="<?php echo e(count($taxes) > 1 ? '20' : '25'); ?>"
                                                  rows="3" style="height: 40px; border: none; outline: none; resize: none; width: 100%"
                                                  wire:model="descriptions.<?php echo e($index); ?>"
                                        ></textarea>
                                    <?php $__errorArgs = ['description.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </td>
                        <!--Unit Price-->
                        <td  class="pt-0 pb-0" style="width: <?php echo e(count($taxes) > 1 ? '8%' : ''); ?>">
                            <div class="form-group col-md-12 mb-0 w-100">
                                <input id="unit_price.<?php echo e($index); ?>"
                                       type="number"
                                       class="<?php $__errorArgs = ['unit_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-0 w-100 inv-unit_price"
                                       name="unit_price[]"
                                       style="outline: none"
                                       wire:model="unit_prices.<?php echo e($index); ?>"
                                       <?php echo e(isset($quantities[$index]) ? '' : 'disabled'); ?>

                                       onkeypress="restrictMinus(event);"
                                >
                                <?php $__errorArgs = ['unit_price.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </td>
                        <!--Quantity-->
                        <td  class="pt-0 pb-0" style="background-color: <?php echo e(isset($descriptions[$index]) ? '#FFFBE5' : ''); ?>">
                            <div class="form-group col-md-12 mb-0 w-100">
                                <input id="quantity.<?php echo e($index); ?>"
                                       type="number"
                                       class="<?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-0 w-100 inv-quantity"
                                       name="quantity[]"
                                       style="outline: none; background-color: <?php echo e(isset($descriptions[$index]) ? '#FFFBE5' : ''); ?>"
                                       wire:model="quantities.<?php echo e($index); ?>"
                                       <?php echo e(isset($descriptions[$index]) ? '' : 'disabled'); ?>

                                       <?php echo e(isset($descriptions[$index]) ? 'autofocus' : ''); ?>

                                       onkeypress="restrictMinus(event);"
                                >
                                <?php $__errorArgs = ['quantity.'.$index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </td>
                        <!--First tax-->
                        <td class="pt-0 pb-0" style="width: 15%">
                            <div class="form-group col-md-12 mb-0 w-100">
                                <select id="first_tax_id.<?php echo e($index); ?>"
                                        class="<?php $__errorArgs = ['first_tax_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-0"
                                        name='first_tax_id[]' style="outline: none; width: 100%" wire:model="first_tax_ids.<?php echo e($index); ?>">
                                    <option value="" selected></option>
                                    <?php if(isset($descriptions[$index])): ?>
                                        <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tax->id); ?>">
                                                <?php echo e(app()->getLocale() == 'ar' ? $tax->tax_name_ar : $tax->tax_name_en); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="" disabled style="color: #333333 !important;"><?php echo e(trans('applang.first_tax')); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <input type="text" wire:model="first_tax_items_val.<?php echo e($index); ?>" class="tax-input" disabled>
                        </td>
                        <!--Second tax-->
                        <?php if(count($taxes) > 1): ?>
                            <td class="pt-0 pb-0" style="width: 15%">
                                <div class="form-group col-md-12 mb-0 w-100">
                                    <select id="second_tax_id.<?php echo e($index); ?>"
                                            class="<?php $__errorArgs = ['second_tax_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-0"
                                            name='second_tax_id[]' style="outline: none; width: 100%" wire:model="second_tax_ids.<?php echo e($index); ?>">
                                        <option value="" selected></option>
                                        <?php if(isset($first_tax_ids[$index])): ?>
                                            <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tax->id); ?>">
                                                    <?php echo e(app()->getLocale() == 'ar' ? $tax->tax_name_ar : $tax->tax_name_en); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="" disabled style="color: #333333 !important;"><?php echo e(trans('applang.second_tax')); ?></option>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <input type="text" wire:model="second_tax_items_val.<?php echo e($index); ?>" class="tax-input" disabled>
                            </td>
                        <?php endif; ?>
                    <!--row total-->
                        <td class="pt-0 pb-0" style="background-color: #EEEEEE; width: 15%">
                            <div class="form-group col-md-12 mb-0">
                                <input id="row_total.<?php echo e($index); ?>"
                                       type="text"
                                       class="<?php $__errorArgs = ['row_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-0 w-100"
                                       name="row_total[]"
                                       value="<?php echo e($row_total && isset($row_total[$index]) ? $row_total[$index] : '0.00'); ?> <?php echo e($currency_symbol); ?>"
                                       style="outline: none; background-color: #EEE"
                                       readonly
                                >
                            </div>
                        </td>
                        <!--Delete row button-->
                        <?php if($loop->index > 0): ?>
                            <td class="pt-0 pb-0" style="background-color: #f5f5f5; padding-left: 5px !important; padding-right: 5px !important; width: 3%">
                                <button class="btn btn-danger btn-xs" wire:ignore wire:click.prevent="removeProduct(<?php echo e($index); ?>)"><i class="bx bx-x-circle"></i></button>
                            </td>
                        <?php else: ?>
                            <td class="pt-0 pb-0" style="background-color: #f5f5f5; padding-left: 5px !important; padding-right: 5px !important; width: 3%"></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!--total before or subtotal-->
                <!--subtotal-->
                <tr style="background-color: #EEEEEE; font-weight: bolder">
                    <td class="table-invoice-totals" style="border-bottom: none;padding-top: 0 !important;" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>">
                        <button class="btn btn-primary btn-sm" type="button" style="border-radius: 0" wire:click.prevent="addMoreProduct"
                            <?php echo e($showAddMoreBtn == false ? 'disabled' : ''); ?>

                        >
                            <i class="bx bx-plus"></i>
                            <span class="invoice-repeat-btn"><?php echo e(trans('applang.add_line')); ?></span>
                        </button>
                    </td>
                    <td class="text-center table-invoice-totals black"><?php echo e(trans('applang.total_before')); ?></td>
                    <td class="table-invoice-totals">
                        <div class="form-group col-md-12 mb-0">
                            <input id="subtotal"
                                   type="text"
                                   class="border-0 w-100"
                                   name="subtotal"
                                   value="<?php echo e($subtotal ?? '0.00'); ?> <?php echo e($currency_symbol); ?>"
                                   style="outline: none; background-color: #EEE; font-weight: bold"
                                   readonly
                            >
                        </div>
                    </td>
                    <td class="table-invoice-totals"></td>
                </tr>
                <!--discount-->
                <?php if($discount && $discount_inv && $discount_type != '' && $subtotal != ''): ?>
                    <tr style="background-color: #EEEEEE; font-weight: bolder">
                        <td class="table-invoice-totals" style="border-bottom: none" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>"></td>
                        <td class="text-center table-invoice-totals black"><?php echo e(trans('applang.discount')); ?></td>
                        <td class="table-invoice-totals">
                            <div class="form-group col-md-12 mb-0">
                                <input id="discount_inv"
                                       type="text"
                                       class="border-0 w-100"
                                       name="discount_inv"
                                       value="<?php echo e(isset($discount_inv) ? '-'.' '.$discount_inv :'0.00'); ?> <?php echo e($currency_symbol); ?>"
                                       style="outline: none; background-color: #EEE; font-weight: bold"
                                       readonly
                                >
                            </div>
                        </td>
                        <td class="table-invoice-totals"></td>
                    </tr>
                <?php endif; ?>
                <!--taxes-->
                <?php if($total_taxes_ids): ?>
                    <?php $__currentLoopData = $total_taxes_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $total_tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($total_tax_inv[$key]): ?>
                            <tr style="background-color: #EEEEEE; font-weight: bolder">
                                <td class="table-invoice-totals" style="border-bottom: none" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>"></td>
                                <td class="text-center table-invoice-totals black">
                                    <div class="form-group col-md-12 mb-0">
                                        <input id="total_tax_inv.<?php echo e($key); ?>"
                                               type="text"
                                               class="border-0 w-100"
                                               name="total_tax_inv[]"
                                               value="<?php echo e(app()->getLocale() == 'ar' ? $total_tax_inv[$key]['tax_name_ar'] : $total_tax_inv[$key]['tax_name_en']); ?> (<?php echo e(number_format($total_tax_inv[$key]['tax_value'])); ?>%) "
                                               style="outline: none; background-color: #EEE; text-align: center; font-weight: bold"
                                               readonly
                                        >
                                    </div>
                                </td>
                                <td class="table-invoice-totals">
                                    <div class="form-group col-md-12 mb-0">
                                        <input id="total_tax_inv_sum.<?php echo e($key); ?>"
                                               type="text"
                                               class="border-0 w-100"
                                               name="total_tax_inv_sum[]"
                                               value="<?php echo e(isset($total_tax_inv_sum)? array_sum(array_column($total_tax_inv_sum, $total_tax_inv[$key]['id'])) : '00.0'); ?> <?php echo e($currency_symbol); ?>"
                                               style="outline: none; background-color: #EEE; font-weight: bold"
                                               readonly
                                        >
                                    </div>
                                </td>
                                <td class="table-invoice-totals"></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <!--shipping expenses-->
                <?php if($shipping_expense && $subtotal != ''): ?>
                    <tr style="background-color: #EEEEEE; font-weight: bolder">
                        <td class="table-invoice-totals" style="border-bottom: none" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>"></td>
                        <td class="text-center table-invoice-totals black"><?php echo e(trans('applang.shipping_expense')); ?></td>
                        <td class="table-invoice-totals">
                            <div class="form-group col-md-12 mb-0">
                                <input id="shipping_expense_inv"
                                       type="text"
                                       class="border-0 w-100"
                                       name="shipping_expense_inv"
                                       value="<?php echo e(isset($shipping_expense_inv) ? $shipping_expense_inv :'0.00'); ?> <?php echo e($currency_symbol); ?>"
                                       style="outline: none; background-color: #EEE; font-weight: bold"
                                       readonly
                                >
                            </div>
                        </td>
                        <td class="table-invoice-totals"></td>
                    </tr>
                <?php endif; ?>
                <!--down payment-->
                <?php if($down_payment && $down_payment_inv && $down_payment_type != null && $subtotal != '' && $deposit_is_paid == true): ?>
                    <tr style="background-color: #EEEEEE; font-weight: bolder">
                        <td class="table-invoice-totals" style="border-bottom: none" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>"></td>
                        <td class="text-center table-invoice-totals black"><?php echo e(trans('applang.down_payment')); ?></td>
                        <td class="table-invoice-totals">
                            <div class="form-group col-md-12 mb-0">
                                <input id="down_payment_inv"
                                       type="text"
                                       class="border-0 w-100"
                                       name="down_payment_inv"
                                       value="<?php echo e(isset($down_payment_inv) ? '-'.' '.$down_payment_inv :'0.00'); ?> <?php echo e($currency_symbol); ?>"
                                       style="outline: none; background-color: #EEE; font-weight: bold"
                                       readonly
                                >
                            </div>
                        </td>
                        <td class="table-invoice-totals"></td>
                    </tr>
                <?php endif; ?>
                <!--due amount-->
                <tr style="background-color: #EEEEEE; font-weight: bolder">
                    <td class="table-invoice-totals" style="border-bottom: <?php echo e($paid_to_supplier_checkbox ? 'none' : ''); ?>" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>"></td>
                    <td class="text-center table-invoice-totals black"><?php echo e(trans('applang.due_amount')); ?></td>
                    <td class="table-invoice-totals">
                        <div class="form-group col-md-12 mb-0">
                            <input id="due_amount"
                                   type="text"
                                   class="border-0 w-100"
                                   name="due_amount"
                                   value="<?php echo e(isset($due_amount) ? $due_amount :'0.00'); ?> <?php echo e($currency_symbol); ?>"
                                   style="outline: none; background-color: #EEE; font-weight: bold"
                                   readonly
                            >
                        </div>
                    </td>
                    <td class="table-invoice-totals"></td>
                </tr>
                <!--Paid To Supplier-->
                <?php if($paid_to_supplier_checkbox && $due_amount != ''): ?>
                    <tr style="background-color: #EEEEEE; font-weight: bolder">
                        <td class="table-invoice-totals" style="border-bottom: none" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>"></td>
                        <td class="text-center table-invoice-totals black"><?php echo e(trans('applang.paid')); ?></td>
                        <td class="table-invoice-totals">
                            <div class="form-group col-md-12 mb-0">
                                <input id="paid_to_supplier_inv$table->decimal('down_payment_inv', 8, 2)->default(0.00);"
                                       type="text"
                                       class="border-0 w-100"
                                       name="paid_to_supplier_inv"
                                       value="<?php echo e('-'.$paid_to_supplier_inv ?? '0.00'); ?> <?php echo e($currency_symbol); ?>"
                                       style="outline: none; background-color: #EEE; font-weight: bold"
                                       readonly
                                >
                            </div>
                        </td>
                        <td class="table-invoice-totals"></td>
                    </tr>
                    <!--Due After Paid-->
                    <tr style="background-color: #EEEEEE; font-weight: bolder">
                        <td class="table-invoice-totals" colspan="<?php echo e(count($taxes) > 1 ? '5' : '4'); ?>"></td>
                        <td class="text-center table-invoice-totals black"><?php echo e(trans('applang.due_amount_after_paid')); ?></td>
                        <td class="table-invoice-totals">
                            <div class="form-group col-md-12 mb-0">
                                <input id="due_amount_after_paid"
                                       type="text"
                                       class="border-0 w-100"
                                       name="due_amount_after_paid"
                                       value="<?php echo e('0.00'); ?> <?php echo e($currency_symbol); ?>"
                                       style="outline: none; background-color: #EEE; font-weight: bold"
                                       readonly
                                >
                            </div>
                        </td>
                        <td class="table-invoice-totals"></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!--Other Data-->
        <ul class="inv_other_data nav nav-tabs mb-0" id="myTab" role="tablist" wire:ignore>
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#discountAndDownpayment" role="tab" aria-controls="home" aria-selected="true"><?php echo e(trans('applang.discount')); ?> & <?php echo e(trans('applang.down_payment')); ?></a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="contact-tab" data-toggle="tab" href="#shippingExpense" role="tab" aria-controls="shippingExpense" aria-selected="false"><?php echo e(trans('applang.shipping')); ?></a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="contact-tab" data-toggle="tab" href="#attachDocuments" role="tab" aria-controls="attachDocuments" aria-selected="false"><?php echo e(trans('applang.attach_documents')); ?></a>
            </li>
        </ul>

        <div class="tab-content mb-1" style="padding: 10px; background-color: #edf1f2" id="myTabContent" wire:ignore>
            <div class="tab-pane fade show active" id="discountAndDownpayment" role="tabpanel" aria-labelledby="discountAndDownpayment-tab">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-row mb-50">
                            <!--Discount-->
                            <div class="col-md-6">
                                <label for="discount"><?php echo e(trans('applang.discount')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="discount"
                                           type="number"
                                           class="form-control"
                                           name="discount"
                                           placeholder="<?php echo e(trans('applang.discount')); ?>"
                                           wire:model="discount"
                                           onkeypress="restrictMinus(event);"
                                    >
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php if($errors->has('discount')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('discount')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!--Discount type-->
                            <div class="col-md-6">
                                <label for="discount_type"><?php echo e(trans('applang.discount_type')); ?></label>
                                <fieldset class="form-group">
                                    <select id="discount_type" class="custom-select " name="discount_type" wire:model="discount_type">
                                        <option value="" selected="" ><?php echo e(trans('applang.select_discount_type')); ?></option>
                                        <option value="1"><?php echo e(trans('applang.percentage')); ?></option>
                                        <option value="0"><?php echo e(trans('applang.cash_amount')); ?></option>
                                    </select>
                                    <?php if($errors->has('discount_type')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('discount_type')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-6">
                        <!--Down payment-->
                        <div x-data="{ open: false }" class="down-div">
                            <div class="form-row mb-50">
                                <div class="col-md-12">
                                    <label for=""><?php echo e(trans('applang.down_payment')); ?></label>
                                    <div class="down-payment-head">
                                        <fieldset>
                                            <div class="checkbox checkbox-primary">
                                                <input type="checkbox" id="deposit_is_paid" @click="open = ! open" wire:model="deposit_is_paid">
                                                <label style="font-size: small" for="deposit_is_paid"><?php echo e(trans('applang.already_paid')); ?></label>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </div>

                            <div x-show="open">
                                <div class="form-row">
                                    <!--Down payment-->
                                    <div class="col-md-6">
                                        <label class="required" for="down_payment"><?php echo e(trans('applang.paid_amount')); ?></label>
                                        <div class="position-relative has-icon-left">
                                            <input id="down_payment"
                                                   type="number"
                                                   class="form-control <?php $__errorArgs = ['down_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   name="down_payment"
                                                   placeholder="<?php echo e(trans('applang.down_payment')); ?>"
                                                   autocomplete="down_payment"
                                                   wire:model="down_payment"
                                                   onkeypress="restrictMinus(event);">
                                            <div class="form-control-position">
                                                <i class="bx bx-pen"></i>
                                            </div>
                                            <?php if($errors->has('down_payment')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('down_payment')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <!--Down payment type-->
                                    <div class="col-md-6">
                                        <label class="required" for="down_payment_type"><?php echo e(trans('applang.down_payment_type')); ?></label>
                                        <fieldset class="form-group">
                                            <select id="down_payment_type" class="custom-select <?php $__errorArgs = ['down_payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="down_payment_type" wire:model="down_payment_type">
                                                <option value="" selected=""><?php echo e(trans('applang.select_down_payment_type')); ?></option>
                                                <option value="1"><?php echo e(trans('applang.percentage')); ?></option>
                                                <option value="0"><?php echo e(trans('applang.cash_amount')); ?></option>
                                            </select>
                                            <?php if($errors->has('down_payment_type')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('down_payment_type')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </fieldset>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <!--Deposit Method-->
                                    <div class="col-md-6">
                                        <label class="required" for="deposit_payment_method"><?php echo e(trans('applang.deposit_payment_method')); ?></label>
                                        <fieldset class="form-group">
                                            <select id="deposit_payment_method" class="custom-select <?php $__errorArgs = ['deposit_payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="deposit_payment_method" wire:model="deposit_payment_method">
                                                <option value="" selected=""><?php echo e(trans('applang.select_deposit_payment_method')); ?></option>
                                                <option value="cash"><?php echo e(trans('applang.cash_amount')); ?></option>
                                                <option value="cheque"><?php echo e(trans('applang.cheque')); ?></option>
                                                <option value="bank_transfer"><?php echo e(trans('applang.bank_transfer')); ?></option>
                                            </select>
                                            <?php if($errors->has('deposit_payment_method')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('deposit_payment_method')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </fieldset>
                                    </div>
                                    <!--Reference Number-->
                                    <div class="col-md-6">
                                        <label class="required" for="deposit_transaction_id"><?php echo e(trans('applang.reference_number')); ?></label>
                                        <div class="position-relative has-icon-left">
                                            <input id="deposit_transaction_id"
                                                   type="number"
                                                   class="form-control <?php $__errorArgs = ['deposit_transaction_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   name="deposit_transaction_id"
                                                   placeholder="<?php echo e(trans('applang.reference_number')); ?>"
                                                   wire:model="deposit_transaction_id"
                                                   onkeypress="restrictMinus(event);"
                                            >
                                            <div class="form-control-position">
                                                <i class="bx bx-pen"></i>
                                            </div>
                                            <?php if($errors->has('deposit_transaction_id')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('deposit_transaction_id')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <div class="tab-pane fade" id="shippingExpense" role="tabpanel" aria-labelledby="shipping_expense-tab">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-row mb-50">
                            <!--Warehouse-->
                            <div class="col-md-6">
                                <label class="required" for="warehouse_id"><?php echo e(trans('applang.warehouses')); ?></label>
                                <fieldset class="form-group">
                                    <select id="warehouse_id" class="custom-select <?php $__errorArgs = ['warehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="warehouse_id">
                                        <option value="" selected="" disabled=""><?php echo e(trans('applang.select_warehouse')); ?></option>
                                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('warehouse_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('warehouse_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                            <!--Shipping Expenses-->
                            <div class="col-md-6">
                                <label for="shipping_expense"><?php echo e(trans('applang.shipping_expense')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="shipping_expense"
                                           type="number"
                                           class="form-control"
                                           name="shipping_expense"
                                           placeholder="<?php echo e(trans('applang.shipping_expense')); ?>"
                                           autocomplete="shipping_expense"
                                           wire:model="shipping_expense"
                                           onkeypress="restrictMinus(event);">
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="attachDocuments" role="tabpanel" aria-labelledby="attachDocuments-tab">
                <div class="row justify-content-center">
                    <!--Attachments-->
                    <div class="col-md-12">
                        <input type="file" id="attachedDocuments" name="attachments[]"  class="file" multiple
                               data-preview-file-type="text"
                               data-browse-on-zone-click="true"
                               data-show-upload="false"
                               data-show-caption="true"
                               data-msg-placeholder=""
                        >
                    </div>
                </div>
            </div>
        </div>

        <!--Notes-->
        <div class="mt-1 mb-50" wire:ignore>
            <label for="editor"><?php echo e(trans('applang.notes')); ?></label>
            <textarea id="editor" name="notes"></textarea>
        </div>

        <hr class="hr-dotted">

        <!--Payment to supplier-->
        <div class="form-row" style=" background-color: #edf1f2; padding: 10px">
            <div class="col-md-6">
                <div x-data="{ open: false }">
                    <div class="form-row mb-50">
                        <div class="col-md-12">
                            <label for="paid_to_supplier_checkbox"><?php echo e(trans('applang.full_payment')); ?></label>
                            <div class="down-payment-head" style="width: 98% !important;">
                                <fieldset>
                                    <div class="checkbox checkbox-primary">
                                        <input type="checkbox" id="paid_to_supplier_checkbox" @click="open = ! open" wire:model="paid_to_supplier_checkbox">
                                        <label style="font-size: small" for="paid_to_supplier_checkbox"><?php echo e(trans('applang.already_paid_to_supplier')); ?></label>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                    </div>

                    <div x-show="open">
                        <div class="form-row col-md-12 pl-0 pr-0">
                            <!--Payment Method-->
                            <div class="col-md-6">
                                <label class="required" for="payment_payment_method"><?php echo e(trans('applang.payment_payment_method')); ?></label>
                                <fieldset class="form-group">
                                    <select id="payment_payment_method" class="custom-select <?php $__errorArgs = ['payment_payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="payment_payment_method" wire:model="payment_payment_method">
                                        <option value="" selected=""><?php echo e(trans('applang.select_payment_payment_method')); ?></option>
                                        <option value="cash"><?php echo e(trans('applang.cash_amount')); ?></option>
                                        <option value="cheque"><?php echo e(trans('applang.cheque')); ?></option>
                                        <option value="bank_transfer"><?php echo e(trans('applang.bank_transfer')); ?></option>
                                    </select>
                                    <?php if($errors->has('payment_payment_method')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('payment_payment_method')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </fieldset>
                            </div>
                            <!--Reference Number-->
                            <div class="col-md-6">
                                <label class="required" for="payment_transaction_id"><?php echo e(trans('applang.reference_number')); ?></label>
                                <div class="position-relative has-icon-left">
                                    <input id="payment_transaction_id"
                                           type="number"
                                           class="form-control <?php $__errorArgs = ['payment_transaction_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="payment_transaction_id"
                                           placeholder="<?php echo e(trans('applang.reference_number')); ?>"
                                           wire:model="payment_transaction_id"
                                           onkeypress="restrictMinus(event);"
                                    >
                                    <div class="form-control-position">
                                        <i class="bx bx-pen"></i>
                                    </div>
                                    <?php if($errors->has('payment_transaction_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('payment_transaction_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <input type="hidden" value="<?php echo e($payment_status); ?>" name="payment_status">
        <input type="hidden" value="<?php echo e($receiving_status); ?>" name="receiving_status">
        <input type="hidden" value="<?php echo e($total_inv); ?>" name="total_inv">

        <hr class="hr modal-hr">
        <div class="d-flex justify-content-end mt-2rem">
            <a href="<?php echo e(route('sales-invoices.index')); ?>" class="btn btn-light-secondary" data-dismiss="modal">
                <i class="bx bx-x d-block d-sm-none"></i>
                <span class="d-none d-sm-block"><?php echo e(trans('applang.back_btn')); ?></span>
            </a>
            <button type="submit" class="btn btn-primary ml-1">
                <i class="bx bx-check d-block d-sm-none"></i>
                <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
            </button>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/erp/sales/sales-invoices/create-sales-invoice.blade.php ENDPATH**/ ?>