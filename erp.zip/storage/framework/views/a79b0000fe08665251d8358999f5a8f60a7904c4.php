<?php $__env->startSection('title', trans('applang.general_settings')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
    <link rel="stylesheet" href="<?php echo e(asset('app-assets/vendors/css/forms/select/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!--Start Update -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('general-settings.update', 'create')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card">
                        <div class="card-header modal-header bg-primary">
                            <h4 class="modal-title white"><?php echo e(trans('applang.general_settings')); ?></h4>
                        </div>
                        <div class="card-body mt-1" style="padding-bottom: 13px">

                            <!--Business Details-->
                            <div class="custom-card mt-1 mb-5">
                                <div class="card-header border-bottom" style="background-color: #f9f9f9">
                                    <span class="text-bold-700 pr-1 pl-1"><?php echo e(trans('applang.business_details')); ?></span>
                                </div>

                                <div class="card-body mt-1">

                                    <!--Business Name-->
                                    <div class="col-md-12 mb-50">
                                        <label class="required" for="business_name"><?php echo e(trans('applang.business_name')); ?></label>
                                        <div class="position-relative has-icon-left">
                                            <input id="business_name"
                                                   type="text"
                                                   class="form-control <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   name="business_name"
                                                   placeholder="<?php echo e(trans('applang.business_name')); ?>"
                                                   autocomplete="business_name"
                                                   value="<?php echo e($gs->business_name ?? old('business_name')); ?>"
                                                   autofocus>
                                            <div class="form-control-position">
                                                <i class="bx bx-pen"></i>
                                            </div>
                                            <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!--First name & Last name-->
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="first_name"><?php echo e(trans('applang.first_name')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="first_name"
                                                           type="text"
                                                           class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="first_name"
                                                           placeholder="<?php echo e(trans('applang.first_name')); ?>"
                                                           autocomplete="first_name"
                                                           value="<?php echo e($gs->first_name ?? old('first_name')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="last_name"><?php echo e(trans('applang.last_name')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="last_name"
                                                           type="text"
                                                           class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="last_name"
                                                           placeholder="<?php echo e(trans('applang.last_name')); ?>"
                                                           autocomplete="last_name"
                                                           value="<?php echo e($gs->last_name ?? old('last_name')); ?>"
                                                    >
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--Country & State & City-->
                                    <div class="form-row">
                                        <div class="col-md-4">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="country"><?php echo e(trans('applang.country')); ?></label>
                                                <fieldset class="form-group">
                                                    <select id="country" class="custom-select <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='country'>
                                                        <option value="" selected disabled><?php echo e(trans('applang.select_country')); ?></option>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>" <?php echo e(isset($gs) && $gs->country == $key ? 'selected' : ''); ?>>
                                                                <?php echo e(app()->getLocale() == 'ar' ? $value['name'] : $value['en_name']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php if($errors->has('country')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('country')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </fieldset>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="state"><?php echo e(trans('applang.state')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="state"
                                                           type="text"
                                                           class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="state"
                                                           placeholder="<?php echo e(trans('applang.state')); ?>"
                                                           autocomplete="state"
                                                           value="<?php echo e($gs->state ?? old('state')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="city"><?php echo e(trans('applang.city')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="city"
                                                           type="text"
                                                           class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="city"
                                                           placeholder="<?php echo e(trans('applang.city')); ?>"
                                                           autocomplete="city"
                                                           value="<?php echo e($gs->city ?? old('city')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--Street Adress & Postal Code-->
                                    <div class="form-row">
                                        <div class="col-md-9">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="street_address"><?php echo e(trans('applang.street_address')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="street_address"
                                                           type="text"
                                                           class="form-control <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="street_address"
                                                           placeholder="<?php echo e(trans('applang.street_address')); ?>"
                                                           autocomplete="street_address"
                                                           value="<?php echo e($gs->street_address ?? old('street_address')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="postal_code"><?php echo e(trans('applang.postal_code')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="postal_code"
                                                           type="number"
                                                           class="form-control <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="postal_code"
                                                           placeholder="<?php echo e(trans('applang.postal_code')); ?>"
                                                           autocomplete="postal_code"
                                                           value="<?php echo e($gs->postal_code ?? old('postal_code')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--Phone & Mobile-->
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="phone"><?php echo e(trans('applang.phone')); ?></label>
                                                <div class="input-group" dir="ltr">
                                                    <div class="input-group-append" style="width: 20%">
                                                        <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                               placeholder="&#9872; &#9743;" value="<?php echo e($gs->phone_code ?? old('phone_code')); ?>">
                                                    </div>
                                                    <input id="phone"
                                                           type="number"
                                                           class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                                           name="phone"
                                                           placeholder="<?php echo e(trans('applang.phone')); ?>"
                                                           autocomplete="phone"
                                                           value="<?php echo e($gs->phone ?? old('phone')); ?>"
                                                           autofocus>
                                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="mobile"><?php echo e(trans('applang.mobile')); ?></label>
                                                <div class="input-group" dir="ltr">
                                                    <div class="input-group-append" style="width: 20%">
                                                        <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                               placeholder="&#9872; &#9743;" value="<?php echo e($gs->phone_code ?? old('phone_code')); ?>">
                                                    </div>
                                                    <input id="mobile"
                                                           type="number"
                                                           class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                                           name="mobile"
                                                           placeholder="<?php echo e(trans('applang.mobile')); ?>"
                                                           autocomplete="mobile"
                                                           value="<?php echo e($gs->mobile ?? old('mobile')); ?>"
                                                           autofocus>
                                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--Fax & Email-->
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="mobile"><?php echo e(trans('applang.fax')); ?></label>
                                                <div class="input-group" dir="ltr">
                                                    <div class="input-group-append" style="width: 20%">
                                                        <input type="text" class="form-control text-append-phone-code phone_code text-center" readonly name="phone_code"
                                                               placeholder="&#9872; &#9743;" value="<?php echo e($gs->phone_code ?? old('phone_code')); ?>">
                                                    </div>
                                                    <input id="fax"
                                                           type="number"
                                                           class="form-control <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-phone"
                                                           name="fax"
                                                           placeholder="<?php echo e(trans('applang.fax')); ?>"
                                                           autocomplete="fax"
                                                           value="<?php echo e($gs->fax ?? old('fax')); ?>"
                                                           autofocus>
                                                    <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="email"><?php echo e(trans('applang.email')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="email"
                                                           type="email"
                                                           class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="email"
                                                           placeholder="<?php echo e(trans('applang.email')); ?>"
                                                           autocomplete="email"
                                                           value="<?php echo e($gs->email ?? old('email')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--Commercial Record & Tax Registration-->
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="commercial_record"><?php echo e(trans('applang.commercial_record')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="commercial_record"
                                                           type="text"
                                                           class="form-control <?php $__errorArgs = ['commercial_record'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="commercial_record"
                                                           placeholder="<?php echo e(trans('applang.commercial_record')); ?>"
                                                           autocomplete="commercial_record"
                                                           value="<?php echo e($gs->commercial_record ?? old('commercial_record')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['commercial_record'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="tax_registration"><?php echo e(trans('applang.tax_registration')); ?></label>
                                                <div class="position-relative has-icon-left">
                                                    <input id="tax_registration"
                                                           type="text"
                                                           class="form-control <?php $__errorArgs = ['tax_registration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                           name="tax_registration"
                                                           placeholder="<?php echo e(trans('applang.tax_registration')); ?>"
                                                           autocomplete="tax_registration"
                                                           value="<?php echo e($gs->tax_registration ?? old('tax_registration')); ?>"
                                                           autofocus>
                                                    <div class="form-control-position">
                                                        <i class="bx bx-pen"></i>
                                                    </div>
                                                    <?php $__errorArgs = ['tax_registration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <!--App Settings-->
                            <div class="custom-card mt-1 mb-5">
                                <div class="card-header border-bottom" style="background-color: #f9f9f9">
                                    <span class="text-bold-700 pr-1 pl-1"><?php echo e(trans('applang.app_settings')); ?></span>
                                </div>

                                <div class="card-body mt-1">

                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <!--Timezone-->
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="time_zone"><?php echo e(trans('applang.time_zone')); ?></label>
                                                <fieldset class="form-group">
                                                    <select id="time_zone" class="custom-select <?php $__errorArgs = ['time_zone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='time_zone'>
                                                        <option value="" selected disabled><?php echo e(trans('applang.select_time_zone')); ?></option>
                                                        <?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e(reset($value['utc'])); ?>" <?php echo e(isset($gs) && $gs->time_zone ==  reset($value['utc']) ? 'selected' : ''); ?>><?php echo e($value['text']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('time_zone')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('time_zone')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>
                                                </fieldset>
                                            </div>
                                            <!--Language-->
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="language"><?php echo e(trans('applang.language')); ?></label>
                                                <fieldset class="form-group">
                                                    <select id="language" class="custom-select <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='language'>
                                                        <option value="" selected disabled><?php echo e(trans('applang.select_language')); ?></option>
                                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($localeCode); ?>" <?php echo e(isset($gs) && $gs->language ==  $localeCode ? 'selected' : ''); ?>><?php echo e($properties['native']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('language')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('language')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </fieldset>
                                            </div>
                                            <!--basic currency-->
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="basic_currency"><?php echo e(trans('applang.basic_currency')); ?></label>
                                                <fieldset class="form-group">
                                                    <div class="input-group-append">
                                                    <select id="basic_currency" class="custom-select <?php $__errorArgs = ['basic_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-append-currency" name='basic_currency'>
                                                        <option value="" selected disabled><?php echo e(trans('applang.select_basic_currency')); ?></option>
                                                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>" <?php echo e(isset($gs) && $gs->basic_currency === $key ? 'selected' : ''); ?>><?php echo e($value['name']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <input type="text" class="form-control text-append-currency-symbol basic-currency-symbol text-center" readonly name="basic_currency_symbol"
                                                           placeholder="<?php echo e(trans('applang.symbol')); ?>" value="<?php echo e($gs->basic_currency_symbol ?? old('basic_currency_symbol')); ?>" style="width:20%">
                                                    </div>
                                                    <?php if($errors->has('basic_currency')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('basic_currency')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </fieldset>
                                            </div>
                                            <!--Extra Currencies-->
                                            <div class="col-md-12 mb-50">
                                                <label class="required" for="extra_currencies"><?php echo e(trans('applang.extra_currencies')); ?></label>
                                                <div class="form-group extra_currencies">
                                                    <select id="extra_currencies" class="select2 form-control <?php $__errorArgs = ['extra_currencies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='extra_currencies[]' multiple="multiple" style="width: 100% !important;">
                                                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>" <?php echo e(isset($gs) && in_array($key,$gs->extra_currencies) ? 'selected' : ''); ?>><?php echo e($value['name']); ?> ( <?php echo e(app()->getLocale() == 'ar' ? $value['symbol_native'] : $value['symbol']); ?> )</option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('extra_currencies')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('extra_currencies')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <!--Logo-->
                                            <div class="col-md-12 mb-50">
                                                <div id='img_contain'><img id="blah" align='middle' src="<?php echo e($gs->logo_path ?? asset('/uploads/logo_image/defaultLogo.png')); ?>" alt="your image" title=''/></div>
                                                <div class="input-group is-invalid">
                                                    <div class="custom-file">
                                                        <input type="file" id="inputGroupFile01" name="logo" class="imgInp custom-file-input" aria-describedby="inputGroupFileAddon01">
                                                        <label class="custom-file-label text-append-logo" for="inputGroupFile01"><?php echo e(trans('applang.choose_logo_file')); ?></label>

                                                    </div>
                                                    <a href="#" class="btn btn-light-info btn-sm remove-logo text-append-reset" title="<?php echo e(trans('applang.reset')); ?>">
                                                        <i class="bx bx-reset"></i>
                                                    </a>
                                                </div>
                                                <?php if($errors->has('logo')): ?>
                                                    <div class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('logo')); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            <input type="hidden" id="hidden-reset" name="reset">
                                        </div>
                                    </div>
                                </div>


                            </div>


                            <hr class="hr modal-hr">
                            <div class="d-flex justify-content-end mt-2rem">
                                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-light-secondary" data-dismiss="modal">
                                    <i class="bx bx-x d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.back_btn')); ?></span>
                                </a>
                                <button type="submit" class="btn btn-primary ml-1">
                                    <i class="bx bx-check d-block d-sm-none"></i>
                                    <span class="d-none d-sm-block"><?php echo e(trans('applang.save')); ?></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--End Update Form -->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/forms/select/select2.full.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>
    <script type="text/javascript">
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
        toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
    <script src="<?php echo e(asset('app-assets/js/scripts/forms/select/form-select2.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#extra_currencies').select2({
                placeholder: "<?php echo e(trans('applang.select_extra_currencies')); ?>",
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            //get the country phone key
            $('#country').on('change', function () {
                var country = $(this).val()
                var url = "<?php echo e(url('/app-assets/data/countries_ar.json')); ?>"
                $.getJSON(url, function(data) {
                    $.map(data, function(value, key) {
                        if (key === country)
                        {
                            // console.log(value.phone_code)
                            $('.phone_code').val( '+ ' + value.phone_code)
                        }
                    });
                });
            });

            //get the basic currency symbol
            $('#basic_currency').on('change', function () {
                var currency = $(this).val()
                var url = "<?php echo e(url('/app-assets/data/currency-symbols.json')); ?>"
                $.getJSON(url, function(data) {
                    $.map(data, function(value, key) {
                        if (key === currency)
                        {
                            if(document.dir === 'rtl'){
                                // console.log(value.phone_code)
                                $('.basic-currency-symbol').val(value.symbol_native)
                            }else{
                                $('.basic-currency-symbol').val(value.symbol)
                            }
                        }
                    });
                });
            });

            //get the extra currencies symbols
            $('#extra_currencies').on('change', function () {
                var currencies = $(this).val();
                var url = "<?php echo e(url('/app-assets/data/currency-symbols.json')); ?>"
                $.getJSON(url, function(data) {
                    $.map(data, function(value, key) {
                        if(document.dir === 'rtl'){
                            if ($.inArray(key, currencies) >= 0)
                            {
                                console.log(value.symbol_native)
                                if(! $(".ex_cur_"+key+"_input").val(value.symbol_native).length > 0){
                                    $('form .extra_currencies').append("<input type='hidden' class='ex_cur_"+key+"_input' name='extra_currencies_symbols[]' value="+value.symbol_native+">")
                                }
                            } else{
                                $(".ex_cur_"+key+"_input").remove()
                            }
                        }else{
                            if ($.inArray(key, currencies) >= 0)
                            {
                                console.log(value.symbol)
                                if(! $(".ex_cur_"+key+"_input").val(value.symbol).length > 0){
                                    $('form .extra_currencies').append("<input type='hidden' class='ex_cur_"+key+"_input' name='extra_currencies_symbols[]' value="+value.symbol+">")
                                }
                            } else{
                                $(".ex_cur_"+key+"_input").remove()
                            }
                        }

                    });
                })
            });

            //logo image preview
            $("#inputGroupFile01").change(function(event) {
                RecurFadeIn();
                readURL(this);
            });
            $("#inputGroupFile01").on('click',function(event){
                RecurFadeIn();
            });
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    var filename = $("#inputGroupFile01").val();
                    filename = filename.substring(filename.lastIndexOf('\\')+1);
                    reader.onload = function(e) {
                        debugger;
                        $('#blah').attr('src', e.target.result);
                        $('#blah').hide();
                        $('#blah').fadeIn(500);
                        $('.custom-file-label').text(filename);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
            function RecurFadeIn(){}

            //reset logo image
            $('.remove-logo').on('click', function(e) {
                $("#hidden-reset").val('hidden-reset');
                var reader = new FileReader();
                e.preventDefault();
                $('#blah').attr('src', '<?php echo e(asset('/uploads/logo_image/defaultLogo.png')); ?>');
                $('#blah').hide();
                $('#blah').fadeIn(500);
                $('.custom-file-label').text('defaultLogo.png');
                $("#inputGroupFile01").val();
                reader.readAsDataURL(input.files[0]);
            });
        });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/settings/general-settings/create.blade.php ENDPATH**/ ?>