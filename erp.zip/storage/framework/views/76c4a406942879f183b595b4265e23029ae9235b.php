<?php $__env->startSection('title', trans('applang.warehouses')); ?>

<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/vendors/css/extensions/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets')); ?>/css/plugins/extensions/toastr.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="content-body">
            <!-- warehouses list start -->
            <section class="users-list-wrapper">
                <div class="default-app-list-table">
                    <div class="card">
                        <div class="card-header justify-content-start">
                            <a href="<?php echo e(route('warehouses.create')); ?>" class="btn btn-success mb-0">
                                <i class="bx bx-plus"></i> <?php echo e(trans('applang.add')); ?>

                            </a>
                        </div>
                        <div class="card-body pt-1 pb-1">
                            <ul class="day-view-entry-list">
                                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="day-view-entry">
                                        <div class="row align-items-center">

                                            <div class="col-md-8">
                                                <a href="<?php echo e(route('warehouses.edit', $warehouse->id)); ?>">
                                                    <div class="project-client">
                                                        <span class="text-black-50">#<?php echo e($index + 1); ?></span>
                                                        <span class="font-weight-bolder font-size-base black"><?php echo e($warehouse->name); ?></span>
                                                    </div>
                                                    <div class=""><span class="text-black-50"><?php echo e($warehouse->shipping_address); ?></span></div>
                                                </a>
                                            </div>

                                            <div class="col-md-2" style="text-align: end">
                                                <?php if($warehouse->status == 1): ?>
                                                    <span class="badge badge-success-custom"><?php echo e(trans('applang.active')); ?></span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger"> <?php echo e(trans('applang.suspended')); ?></span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="dropdown">
                                                    <button class="btn btn-sm btn-light-secondary dropdown-toggle " type="button" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="bx bx-dots-horizontal-rounded"></i>
                                                    </button>
                                                    <div class="dropdown-menu <?php echo e(app()->getLocale() == 'ar' ? 'dropdown-menu-right': ''); ?>">
                                                        <a class="dropdown-item" href="<?php echo e(route('warehouses.edit', $warehouse->id)); ?>" title="<?php echo e(trans('applang.edit')); ?>" >
                                                            <i class="bx bx-edit-alt"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.edit')); ?></span>
                                                        </a>
                                                        <a class="dropdown-item" href="#" title="<?php echo e(trans('applang.delete')); ?>"
                                                           data-toggle="modal"
                                                           data-target="#formModalDeleteWarehouse"
                                                           data-warehouse_id="<?php echo e($warehouse->id); ?>"
                                                           data-name="<?php echo e($warehouse->name); ?>">
                                                            <i class="bx bx-trash"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.delete')); ?></span>
                                                        </a>
                                                        <a class="dropdown-item" href="<?php echo e(route('warehouses.show', $warehouse->id)); ?>" title="<?php echo e(trans('applang.inventory_transactions_summary')); ?>">
                                                            <i class="bx bx-bar-chart-square"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.inventory_transactions_summary')); ?></span>
                                                        </a>
                                                        <a class="dropdown-item" href="<?php echo e(route('inventoryValue', $warehouse->id)); ?>" title="<?php echo e(trans('applang.inventory_value')); ?>">
                                                            <i class="bx bx-line-chart"></i>
                                                            <span class="font-weight-bold ml-1 mr-1"><?php echo e(trans('applang.inventory_value')); ?></span>
                                                        </a>

                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <!-- datatable ends -->

                            <div class="d-flex d-flex justify-content-start custom-pagination">
                                <?php echo $warehouses->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- warehouses list ends -->
        </div>
    </div>

    <!-- Warehouses Modals -->
    <?php echo $__env->make('erp.inventory.warehouses.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<!-- END: Content-->

<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/vendors/js/extensions/sweetalert2.all.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/datatables/datatable-filters.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/modal/components-modal.js"></script>
    <script src="<?php echo e(asset('app-assets')); ?>/js/scripts/extensions/toastr.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#formModalDeleteWarehouse').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget)
                var warehouse_id = button.data('warehouse_id')
                var name = button.data('name')
                var modal = $(this)
                modal.find('.modal-body #warehouse_id').val(warehouse_id)
                modal.find('.modal-body #name').val(name)
            });
        })

        <?php if(count($errors) > 0): ?>
        $('#formModal').modal('show');
        <?php endif; ?>

        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
            }
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.options =
                {
                    "closeButton" : true,
                    "progressBar" : true,
                    "positionClass": "<?php echo e(app()->getLocale() == 'ar' ? 'toast-top-left' : 'toast-top-right'); ?>",
                }
                toastr.error("<?php echo e($error); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/erp/inventory/warehouses/index.blade.php ENDPATH**/ ?>